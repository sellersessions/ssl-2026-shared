# CLAUDE SKILLS REGISTRY

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


**Last Updated:** March 27, 2026
**Maintained By:** Dave
**Purpose:** Canonical record of all Claude skills in use across projects. Upload this file to every project's Project Knowledge. Update this file — and re-upload it plus any changed skill files — whenever a skill is created or modified.

---

## HOW TO USE THIS REGISTRY

**When starting a new project:**
1. Upload this registry file to the new project's Project Knowledge
2. Upload the skill files that apply to that project (see Deployment column below)
3. Note the project in the Deployed To column

**When updating a skill:**
1. Edit the skill file
2. Update the entry below (bump Last Updated, add change note)
3. Re-upload the skill file to all projects listed in Deployed To
4. Re-upload this registry file to all projects listed in Deployed To

**When creating a new skill:**
1. Add an entry below
2. Upload the skill file to all relevant projects
3. Upload this registry to all relevant projects

---

## SKILL INVENTORY

---

### 1. [your-brand]-article-writer

| Field | Value |
|-------|-------|
| **Filename** | `[your-brand]-article-writer-SKILL-v2-1.md` |
| **Last Updated** | March 27, 2026 |
| **Version Notes** | v2.1 — Section 12 added: Content Quality Reference (section progression taxonomy, numbered sections rule, annotated good/bad examples for introductions, content sections, and FAQs). Content migrated from deleted `melatonin-article-template-guide.md`. |
| **Deployed To** | [YOUR_BRAND_NAME] project |

**⚠️ FILENAME CHANGE FROM v2.0:** The previous skill was `[your-brand]-article-writer-SKILL-v2.md`. The v2.1 file is named `[your-brand]-article-writer-SKILL-v2-1.md`. After uploading v2.1 to Project Knowledge, **delete the old `[your-brand]-article-writer-SKILL-v2.md`** to prevent Claude from loading both files and behaving inconsistently.

**What it does:** Produces evidence-based, SEO-optimized [YOUR_BRAND_NAME] health articles as clean HTML ready to paste directly into [YOUR_CMS_PLATFORM]. Runs a two-phase workflow: Phase 1 research (structured source block with journal metadata), Phase 2 article generation (HTML output, all links resolved at generation time). Product-agnostic — works for any [YOUR_BRAND_NAME] supplement. Output includes Research References section with full journal citations.

**Triggers:** "write a [YOUR_BRAND_NAME] article", "create an article for [product]", "start the article workflow", "Phase 1 research", "Phase 2 article"

**Dependencies:** Requires `[your-brand]-schema-generator-SKILL.md` (schema step), `article-link-checker-SKILL.md` (post-generation QA), `melatonin-content-hub-master-index.md` or equivalent hub index (internal linking step), `[your-brand]-article-prompt-reusable-variables.md` (product-specific variables), `[your-brand]-brand-voice-style-guide.md` (tone and language rules)

**Change History:**
- v1.0 — Initial release (January 2026)
- v1.1 — Added stats distribution requirements, Key Takeaways inline CSS format
- v1.2 — Phase session flexibility update; URL slug warning added (March 9, 2026)
- v2.0 — Research References section added; full disclaimers; 3,500-word limit; journal metadata required in Phase 1; TOC and Key Takeaways specified in structure (March 19, 2026)
- v2.1 — Section 12 (Content Quality Reference) added: section progression taxonomy, numbered sections rule, annotated good/bad examples for intros, sections, and FAQs. `melatonin-article-template-guide.md` deleted from Project Knowledge — content consolidated here (March 27, 2026)

---

### 2. [your-brand]-schema-generator

| Field | Value |
|-------|-------|
| **Filename** | `[your-brand]-schema-generator-SKILL.md` |
| **Last Updated** | March 9, 2026 |
| **Version Notes** | v1.2 — Output now wraps JSON-LD in `<script type="application/ld+json">` tags |
| **Deployed To** | [YOUR_BRAND_NAME] project |

**What it does:** Generates complete, validated JSON-LD schema markup for [YOUR_BRAND_NAME] health articles published on [YOUR_CMS_PLATFORM] blogs. Automatically determines required schema types (universal + conditional) based on article characteristics. Outputs production-ready JSON-LD wrapped in `<script>` tags for direct paste into [YOUR_CMS_PLATFORM]'s Custom JSON-LD Schema metafield.

**Triggers:** "generate schema", "create schema for [article]", "run the schema generator", "schema markup"

**Dependencies:** Requires `[your-brand]-schema-generator-products.md` (product catalog) and `[your-brand]-schema-generator-schema-templates.md` (JSON-LD templates) — both must be in Project Knowledge

**Change History:**
- v1.0 — Initial release (January 2026)
- v1.1 — Enumeration validation checklist added after Pharmacy/NutritionalMedicine errors in production
- v1.2 — Script tag wrapping added to output format (March 9, 2026)

---

### 3. article-link-checker

| Field | Value |
|-------|-------|
| **Filename** | `article-link-checker-SKILL.md` |
| **Last Updated** | January 2026 |
| **Version Notes** | v1.0 — Initial release |
| **Deployed To** | [YOUR_BRAND_NAME] project |

**What it does:** Post-generation QA step. Verifies every unique external URL in a generated article is live, that cited source content matches what the article claims, and that anchor text accurately represents the linked page. Outputs a structured audit report with ✅ / ⚠️ / ❌ per URL and a READY TO PUBLISH / NEEDS FIXES verdict.

**Triggers:** "check the links", "verify links", "run the link checker", "are all the links working"

**Dependencies:** None (standalone QA tool)

**Change History:**
- v1.0 — Initial release (January 2026)

---

## SUPPORTING REFERENCE FILES

These are not skills (they don't contain procedural instructions for Claude) but are required by skills above and must be present in the relevant project's Project Knowledge.

| Filename | Required By | Purpose |
|----------|-------------|---------|
| `[your-brand]-schema-generator-products.md` | [your-brand]-schema-generator | Product catalog: names, SKUs, URLs, pricing, descriptions, certifications |
| `[your-brand]-schema-generator-schema-templates.md` | [your-brand]-schema-generator | JSON-LD template library for all schema types |
| `[your-brand]-article-prompt-reusable-variables.md` | [your-brand]-article-writer | Reusable prompt variables for Phase 2 (product URLs, key facts, certifications) |
| `melatonin-content-hub-master-index.md` | [your-brand]-article-writer | Internal linking reference for melatonin hub |
| `vitamin-c-content-hub-master-index.md` | [your-brand]-article-writer | Internal linking reference for vitamin C hub |
| `melatonin-brand-voice-style-guide.md` | [your-brand]-article-writer | Brand voice, tone, writing standards |

### SOPs (not skills — process documents for VA use)

| Filename | Purpose |
|----------|---------|
| `[your-brand]-article-writing-SOP-v1.md` | End-to-end article writing workflow for VAs. Covers all phases: site mapping, keyword definition, research, generation, link verification, internal linking, schema, and publishing. |
| `SOP-article-publishing-shopify.md` | [YOUR_CMS_PLATFORM] publishing steps post-article generation |
| `SOP-schema-generation-shopify.md` | Schema generation and [YOUR_CMS_PLATFORM] metafield insertion |
| `SOP-indexing-google-search-console.md` | [YOUR_SEARCH_CONSOLE] URL submission |

---

## PROJECT DEPLOYMENT MAP

| Project | Skills Deployed | Reference Files Deployed |
|---------|----------------|--------------------------|
| [YOUR_BRAND_NAME] | article-writer v2.1, schema-generator, link-checker | products.md, schema-templates.md, prompt-variables.md, brand-voice.md, melatonin-index.md, vitamin-c-index.md |
| *(future projects)* | | |

---

## PENDING / PLANNED SKILLS

| Skill | Status | Notes |
|-------|--------|-------|
| greatsleep-schema-generator | Planned | WordPress/Rank Math equivalent of [your-brand]-schema-generator. Not yet started. |
| greatsleep-article-writer | Planned | GreatSleep.blog equivalent of [your-brand]-article-writer. Not yet started. |

---

## MASTER SOP STATUS

| SOP | Status | Notes |
|-----|--------|-------|
| Article Writing SOP | ✅ Complete — `[your-brand]-article-writing-SOP-v1.md` | Created March 2026 |
| Article Publishing SOP | ✅ Complete — `SOP-article-publishing-shopify.md` | |
| Schema Generation SOP | ✅ Complete — `SOP-schema-generation-shopify.md` | |
| [YOUR_SEARCH_CONSOLE] Indexing SOP | ✅ Complete — `SOP-indexing-google-search-console.md` | |
| Master/Overarching SOP | ⏳ Pending | To be created once cross-referencing pass is done across all SOPs |

---

*End of registry. Update this file whenever any skill is created, modified, or deployed to a new project.*
