# SOP: Initiate a New [YOUR_BRAND_NAME] Product Content Hub

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---

**Version 1.0 — March 2026**

---

## Where This Fits

This is the first SOP in the [YOUR_BRAND_NAME] content production workflow. Run it once, before any articles are written, for each new product cluster. It is not required for standalone news blog articles.

| Step | SOP | What it produces |
|------|-----|-----------------|
| **0 — Site Mapping** | **This SOP** | Full cluster architecture: article list, URLs, titles, keywords, tags, internal linking plan, and hub index file |
| 0b — URL Placeholders | URL Placeholders SOP (`SOP-[your-brand]-url-placeholders.md`) | Placeholder comments inserted in all articles that link to not-yet-published targets; [YOUR_PROJECT_MANAGEMENT_TOOL] tasks updated with activation instructions |
| 1–5 — Write | Article Writing SOP (`SOP-[your-brand]-article-writing-v1-1.md`) | Finished HTML article |
| 6 — Publish | Article Publishing SOP (`SOP-article-publishing-shopify.md`) | Live [YOUR_CMS_PLATFORM] blog post |
| 7 — Schema | Schema Generation SOP (`SOP-schema-generation-shopify.md`) | JSON-LD schema inserted and validated |
| 8 — Index | Indexing SOP (`SOP-indexing-google-search-console.md`) | Article submitted to Google |

---

**Who this is for:** The person initiating a new product content hub — typically management or a senior VA acting on management instruction. This is a planning step, not a routine article task.

**Assumes:** You have access to a Claude Project (new or existing — see Step 1) and know which [YOUR_BRAND_NAME] product the new hub is for.

---

## Step 1 — Choose or Create a Claude Project

Before running the site mapping prompt, decide whether to use a new or existing Claude Project. Both are valid. Use the table below to decide.

| | New project | Existing [YOUR_BRAND_NAME] project |
|---|---|---|
| **Advantages** | Clean context; easier to track sessions for this product cluster; Claude is less likely to be confused by unrelated files in Project Knowledge | All current skills and reference files already present; no setup required |
| **Disadvantages** | Requires uploading all required skills and SOPs to Project Knowledge before article writing can begin | May accumulate unrelated content over time; context can become cluttered across multiple product hubs |
| **Best for** | New product clusters that will generate a large volume of articles over many sessions | Quick starts, or when the cluster is small and the project is already well-organised |

Whichever option you choose, the Project Knowledge requirements for article writing must be met before Phase 1 of the Article Writing SOP begins. See the Project Knowledge checklist in the Master SOP (`SOP-[your-brand]-master.md`).

**If starting a new project:** After the site mapping session, upload the hub index file Claude generates (see Step 4) plus all required skills and SOPs from the References folder in [YOUR_PROJECT_MANAGEMENT_TOOL] before starting article writing.

---

## Step 2 — Run the Site Mapping Prompt

Open a new chat inside your chosen Claude Project. Paste the following prompt, replacing `[PRODUCT/TOPIC]` with the product name (e.g. "Liposomal Vitamin K2", "Liposomal Magnesium").

---

```
You are an expert in SEO, buyer psychology, and semantic content strategy. Create a comprehensive, search-optimized content hub plan for [PRODUCT/TOPIC] that ranks highly on search engines, matches user intent, and drives conversions by leveraging topical authority and structured value delivery.

Deliverables:

1. Topic Mapping
- Core Concept: Define the overarching topic with clarity, focusing on relevance and search intent alignment.
- Related Subtopics: Identify all subtopics required to build topical authority (pillar page, cluster articles, and phase articles). Ensure subtopics interlink strategically.
- Key Definitions: Define critical terms and jargon within the topic to establish trust and cater to user comprehension.
- Critical Elements: Highlight the essential aspects users are searching for in this topic (e.g. benefits, comparisons, best practices).
- URL Architecture: Map out a clean, hierarchical URL structure that reflects topic relationships and supports crawlability (e.g. domain.com/main-topic/subtopic/specific-guide).

2. Search Intent Match
- User Questions: List specific questions users are searching for related to this topic (FAQs, long-tail keywords, voice-search queries).
- Information Needs: Outline the exact information users need at different stages of their search journey (awareness, consideration, decision).
- Buying Signals: Identify signals that show users are ready to take action (e.g. phrases like "best", "buy", "compare", "how-to").
- Next Steps: Provide logical steps users can take after consuming the content, such as exploring related topics or making a purchase.

3. Content Structure
- Logical Organisation: Create a clear, hierarchical content structure (main topic → subtopic clusters → detailed guides). Use headings that align with search intent.
- Progressive Detail: Start with high-level overviews and dive deeper into each subtopic, ensuring content is digestible and builds trust.
- Strategic Depth: Address every nuance of the topic to demonstrate expertise and authority. Include advanced insights where appropriate.
- Value Delivery: Ensure the content solves the user's problem by providing actionable advice, downloadable resources, or tools.

4. Conversion Elements
- Trust Builders: Include elements that establish trust, such as credentials, case studies, testimonials, or authoritative sources.
- Proof Points: Use data, stats, or user-generated content to reinforce claims and build credibility.
- Calls to Action: Design clear, compelling CTAs (e.g. "Learn More", "Buy Now", "Download Guide") that align with the buyer's stage.
- Next Steps: Suggest logical actions post-conversion, such as exploring related articles, subscribing to newsletters, or downloading advanced guides.

Additional requirements:
- Use topic clusters to interlink related content and dominate search results for the chosen topic.
- Optimise for user intent across the full spectrum of query types: informational, navigational, transactional, and commercial.
- Integrate schema markup considerations (FAQ, How-To, Breadcrumb) for enhanced SERP visibility.
- Maintain clean URL structures, strategic internal linking, and mobile-first optimisation.

For each planned article (pillar, all cluster articles, all phase articles), provide:
- Article title
- Primary keyword
- URL slug
- Tags (5–8 per article, following [YOUR_BRAND_NAME] tagging conventions)
- A single summary sentence suitable for use as a URL placeholder in internal linking before the article is published
- Which other articles in the cluster this article should link to (internal linking plan)
```

---

## Step 3 — Review the Output

Claude will return a detailed cluster plan. Before proceeding, verify the output contains all of the following. If anything is missing, ask Claude to complete it before moving on.

- [ ] Pillar article defined — title, keyword, URL slug, tags, summary sentence, internal links out
- [ ] Cluster articles defined (minimum 4–6) — each with title, keyword, URL slug, tags, summary sentence, internal linking targets
- [ ] Phase articles defined (phases 1, 2, and 3 where applicable) — same fields as above
- [ ] URL architecture is hierarchical and consistent (e.g. all under `/blogs/[product-slug]/`)
- [ ] Internal linking plan covers the full cluster — every article knows what it links to and what links to it
- [ ] No URL slug conflicts with existing published articles (check against the live blog before confirming)

---

## Step 4 — Save the Output to Project Knowledge

Claude will typically offer to generate one or more structured files from the planning output. Accept this. The files it generates should include at minimum:

**Content Hub Master Index** — the canonical reference for all articles in this cluster: titles, URLs, keywords, tags, summary sentences, and internal linking plan. This is the file the Article Writing SOP will reference in Phase 5 (internal linking).

It may also generate:
- Tagging Strategy document
- Brand Voice Style Guide (if not already present in the project)
- Meta Descriptions document

Download any files Claude generates and:
1. Upload them to Project Knowledge in the Claude Project you are using for this hub
2. Save copies to the References folder in [YOUR_PROJECT_MANAGEMENT_TOOL]

> **The Content Hub Master Index is a required Project Knowledge file.** The Article Writing SOP cannot complete Phase 5 (internal linking) without it. Do not begin writing articles until this file is in Project Knowledge.

---

## Step 5 — Set Up Project Knowledge (New Projects Only)

If you created a new Claude Project in Step 1, upload the following to its Project Knowledge before any article writing begins. Retrieve the latest versions from the References folder in [YOUR_PROJECT_MANAGEMENT_TOOL].

**Skills:**

| File | Purpose |
|------|---------|
| `[your-brand]-article-writer-SKILL-v2-1.md` | Article research and generation |
| `article-link-checker-SKILL.md` | Link verification |
| `[your-brand]-schema-generator-SKILL.md` | Schema generation |
| `[your-brand]-schema-generator-products.md` | Product data required by schema generator |
| `[your-brand]-schema-generator-schema-templates.md` | Templates required by schema generator |

**Reference files:**

| File | Purpose |
|------|---------|
| `[your-brand]-article-prompt-reusable-variables.md` | Pre-filled product facts and brand URLs |
| `[your-brand]-brand-voice-style-guide.md` | Tone, language rules, what to avoid |
| `claude-skills-registry.md` | Canonical record of all skills and versions |

**SOPs:**

| File | Purpose |
|------|---------|
| `SOP-[your-brand]-master-1.md` | Master workflow overview |
| `SOP-[your-brand]-site-mapping.md` | This SOP |
| `SOP-[your-brand]-url-placeholders.md` | URL placeholder setup (Phase 0b) |
| `SOP-[your-brand]-article-writing-v1-1.md` | Article writing (Phases 1–5) |
| `SOP-article-publishing-shopify.md` | Publishing to [YOUR_CMS_PLATFORM] |
| `SOP-schema-generation-shopify.md` | Schema generation and insertion |
| `SOP-indexing-google-search-console.md` | [YOUR_SEARCH_CONSOLE] submission |

Confirm each file is present before handing the project to a VA for article writing.

---

## Step 6 — Create [YOUR_PROJECT_MANAGEMENT_TOOL] Tasks

For each article in the cluster plan, create a [YOUR_PROJECT_MANAGEMENT_TOOL] task containing:

- Article title
- Primary keyword
- Secondary keyword (if any)
- URL slug
- Tags
- Article type (pillar / cluster / phase, with phase number)
- Associated product
- Internal linking targets (from the cluster plan)
- *Placeholders this article contains* — list of future links embedded as placeholders, to be activated as targets are published (format per URL Placeholders SOP)
- *Activate placeholders in these articles when published* — list of already-written articles that contain a placeholder waiting for this article

Create tasks for all planned articles now, even those not scheduled to be written for some time. This gives the full cluster visibility in one place and ensures no articles are missed.

> **Note:** Placeholder insertion and [YOUR_PROJECT_MANAGEMENT_TOOL] task tracking for internal links to unpublished articles is covered in full by the URL Placeholders SOP (`SOP-[your-brand]-url-placeholders.md`). Run that SOP (Phase 0b) after completing this one and before beginning article writing.

---

## Completion Gate

Phase 0 is complete when all of the following are true:

- [ ] Content Hub Master Index saved to Project Knowledge
- [ ] Content Hub Master Index saved to [YOUR_PROJECT_MANAGEMENT_TOOL] References folder
- [ ] All cluster articles have [YOUR_PROJECT_MANAGEMENT_TOOL] tasks with complete inputs
- [ ] No URL slug conflicts with existing published articles confirmed
- [ ] Project Knowledge contains all required skills, reference files, and SOPs *(new projects only)*

Only when all items above are checked should article writing begin.

---

## Reference

| Resource | Location |
|----------|----------|
| Master SOP | `SOP-[your-brand]-master-1.md` in Project Knowledge |
| URL Placeholders SOP | `SOP-[your-brand]-url-placeholders.md` in Project Knowledge |
| Article Writing SOP | `SOP-[your-brand]-article-writing-v1-1.md` in Project Knowledge |
| Latest skills and SOPs | References folder in [YOUR_PROJECT_MANAGEMENT_TOOL] |
| Skills Registry | `claude-skills-registry.md` in Project Knowledge |
| [YOUR_BRAND_NAME] [YOUR_CMS_ADMIN] | https://admin.shopify.com |
