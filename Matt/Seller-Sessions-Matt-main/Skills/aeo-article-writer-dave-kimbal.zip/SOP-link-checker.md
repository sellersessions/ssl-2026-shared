# SOP: Link Audit Before Publishing — [YOUR_BRAND_NAME] & GreatSleep

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


**Purpose:** Catch and repair broken, inaccurate, or misleading links in a newly generated article before it is published. This step runs in the same Claude session as article generation — it takes 2–3 minutes and eliminates a class of errors that would otherwise go live.

**Applies to:** [YOUR_BRAND_NAME] ([YOUR_CMS_PLATFORM]) and GreatSleep.blog (WordPress)

**When to run:** After every article is generated, before publishing. This is the final QA step.

---

## Part 1: Which Skill to Use

Two skill files exist — one for each site. Use the one that matches the article you just generated.

| Site | Skill file | Where it lives |
|---|---|---|
| [YOUR_BRAND_NAME] | `article-link-checker-SKILL.md` | [YOUR_BRAND_NAME] Claude Project → Project Knowledge |
| GreatSleep.blog | `greatsleep-link-checker-SKILL.md` | GreatSleep Claude Project → Project Knowledge |

> **Important:** Skills only work within the Claude Project they are uploaded to. If you are working in the [YOUR_BRAND_NAME] project, the [YOUR_BRAND_NAME] skill is already available. If you are working in the GreatSleep project, the GreatSleep skill is already available. You do not need to upload anything — just proceed to Part 2.

> **Before proceeding, verify this manually:** Open Project Knowledge in the current Claude Project and confirm that exactly one link checker skill file is present and that it is the correct one for this site. Claude will not warn you if the skill is missing — it will either attempt the task using general knowledge (without following the skill's structured process) or it may silently use a different skill file if more than one is present. The correct skill file must be in Project Knowledge before you trigger the check.

---

## Part 2: How to Run the Skill

The skill is triggered by natural language. In the same Claude session where the article was generated, type any of the following:

- `Check the links in this article`
- `Verify links`
- `Run the link checker`
- `Are all the links working?`

Claude will:
1. Extract every hyperlink from the article HTML file
2. Run a web search on each unique URL
3. Evaluate liveness, source accuracy, and anchor text accuracy
4. Output a structured audit report

**You do not need to provide the file path separately** if the article was generated in the same session — Claude already has it in context. If you are starting a new session, provide the article HTML file before triggering the skill.

---

## Part 3: Reading the Audit Report

The report uses three status indicators:

| Symbol | Meaning | Action required |
|---|---|---|
| ✅ | Live, source accurate, anchor text accurate | None — link is good |
| ⚠️ | Could not be confirmed via search (may be a new or de-indexed page) | Manual click-check before publishing |
| ❌ | Dead link or source/anchor text mismatch | Must be fixed before publishing |

The report ends with one of two verdicts:

- **READY TO PUBLISH** — all links are ✅, or all ⚠️ items have been manually verified
- **NEEDS FIXES BEFORE PUBLISHING** — one or more ❌ items require repair

Do not publish until the verdict is READY TO PUBLISH.

---

## Part 4: Repairing Broken Links (In-Session)

Because you are still in the same Claude session as article generation, repairs are fast. In many cases Claude will offer to fix problems immediately after reporting them, or will correct them without being asked. The prompts below are fallback examples for situations where Claude does not self-initiate repairs — in practice, you may not need to use them at all. For each ❌ item:

### Broken or dead external link (e.g., a PubMed URL that no longer resolves)

Ask Claude:

> `The link to [URL] is broken. Find a replacement source that supports the same claim and update the article.`

Claude will search for a replacement, propose a new URL, and update the article HTML.

### Source mismatch (the link is live but goes to the wrong content)

Ask Claude:

> `The link at [URL] doesn't match what the article claims. The article says [X] but the linked page is about [Y]. Find a more accurate source and update the article.`

### Anchor text mismatch (the link is live but the clickable text is misleading)

Ask Claude:

> `The anchor text "[anchor text]" at [URL] is inaccurate. Update the anchor text to better reflect what the linked page actually says.`

### After all repairs are made

Ask Claude to re-run the link checker to confirm all fixes:

> `Re-run the link checker on the updated article.`

Do not publish until the re-check returns READY TO PUBLISH.

---

## Part 5: Internal Links

### [YOUR_BRAND_NAME] articles
Internal links (`[YOUR_DOMAIN]/blogs/...`) are cross-referenced against the published article URL list in [YOUR_BRAND_NAME]'s Project Knowledge. If a link cannot be confirmed via search, it may be a new article not yet indexed — Claude will flag it as ⚠️. Manually verify by clicking the URL before publishing.

### GreatSleep.blog articles
Internal links (`greatsleep.blog/...`) are cross-referenced against the GreatSleep published article index in Project Knowledge. Same process applies — ⚠️ flags should be manually click-checked.

### GreatSleep cross-site links to [YOUR_BRAND_NAME]
GreatSleep articles may contain links to [YOUR_BRAND_NAME] product pages (currently: the Liposomal Liquid Melatonin product page). The GreatSleep skill treats these as a separate category and verifies them individually. Ensure anchor text for these links clearly identifies them as product references, not generic phrases.

---

## Part 6: Modifying a Skill (Only If Needed)

In most cases you will not need to modify either skill. The two scenarios where modification may be needed:

**Scenario A: A new [YOUR_BRAND_NAME] product page is being linked from GreatSleep articles**
Open `greatsleep-link-checker-SKILL.md` in the GreatSleep Project Knowledge, locate the *Cross-site Links Check* section, and add the new product URL and its description to the known links list.

**Scenario B: The site domain or publishing platform changes**
Open the relevant skill file, and update:
- The frontmatter `description` field (the one-line summary)
- Any references to the domain name in the *Internal Links Check* section and *Important Notes*
- Any references to [YOUR_CMS_PLATFORM] or WordPress in the intro and output sections

**Scenario C: The skill is making the same mistake or producing the same failure repeatedly**
Do not edit the skill file manually. Instead, describe the problem to Claude in the session and ask it to correct the skill:

> `The link checker skill is [describe the repeated problem]. Please read the skill file and update it to fix this.`

Claude will read the skill, identify the flaw, and produce a corrected version. Once it has done so:
1. Download the corrected skill file from the outputs
2. Go to Project Knowledge in the relevant Claude Project
3. Delete the old skill file
4. Upload the corrected file
5. The fix is live immediately for all future sessions

This approach is preferable to manual editing because Claude understands the full structure of the skill and is less likely to introduce new errors or break formatting in the process.

After modifying a skill file by any method:
1. Delete the old version from Project Knowledge
2. Upload the new version to Project Knowledge
3. The updated skill is immediately active in that project — no other steps needed

> **Reminder:** Skills do not persist automatically between sessions. The skill file in Project Knowledge is the permanent copy. Never rely on a skill that exists only as a file on your local machine or in a session transcript.

---

## Quick Reference Card

```
1. Article generated in Claude session
        ↓
2. Verify Project Knowledge contains exactly one link checker skill — the correct one for this site
        ↓
3. Trigger the skill by name, e.g.:
   "Run the article-link-checker skill on this article" ([YOUR_BRAND_NAME])
   "Run the greatsleep-link-checker skill on this article" (GreatSleep)
   Note: Claude will often find the skill without being given the name, but naming it
   explicitly is safer — especially if more than one skill file is present in Project Knowledge.
        ↓
4. Read the audit report
        ↓
5. Any ❌ items? → Claude will often offer to fix these automatically.
                   If not, use the repair prompts in Part 4.
   Any ⚠️ items? → Manually click-check each URL
        ↓
6. Re-run checker after repairs: "Re-run the link checker"
        ↓
7. Verdict: READY TO PUBLISH → publish
```

---

*Skills referenced: `article-link-checker-SKILL.md` ([YOUR_BRAND_NAME]), `greatsleep-link-checker-SKILL.md` (GreatSleep)*
*Last updated: March 2026*
