---
name: [your-brand]-article-writer-v2
description: Write production-ready [YOUR_BRAND_NAME] health articles as clean HTML fragments for direct [YOUR_CMS_PLATFORM] publishing. Use when creating any [YOUR_BRAND_NAME] supplement article across all products (melatonin, vitamin C, K2, D3+K2, magnesium, collagen, serrapeptase, nattokinase). Runs a two-phase workflow: Phase 1 research prompt (run in separate chat), Phase 2 article generation (HTML output, all links resolved at generation time). Triggers on: "write a [YOUR_BRAND_NAME] article", "create an article for [product]", "start the article workflow", "Phase 1 research", "Phase 2 article".
---

# [YOUR_BRAND_NAME] Article Writer — v2.0

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


Produces evidence-based, SEO-optimized [YOUR_BRAND_NAME] health articles as clean HTML ready to paste directly into [YOUR_CMS_PLATFORM]. No markdown conversion, no post-processing.

**v2 changes from v1:** Word limit raised to 3,500. Research References section added (before disclaimers). Disclaimers updated to full Medical + FDA/Health Canada text. Word distribution targets adjusted proportionally.

---

## BEFORE YOU START — READ THIS

**This skill uses a two-phase workflow.**

- **Phase 1** — Research prompt. Run first. Produces a structured source block.
- **Phase 2** — Article prompt. Takes Phase 1 output as input. Produces the final HTML.

**Both phases can run in the same Claude session** if Phase 1 output is already in context when Phase 2 begins. Use separate sessions when Phase 1 was run in isolation, when collaborating across accounts, or when context has been cleared between phases.

**Do not skip Phase 1.** The article prompt requires pre-researched, structured sources with real URLs. Without them, citations will be fabricated or links will be broken.

**This skill is product-agnostic.** It works for any [YOUR_BRAND_NAME] supplement. When switching products, update the product-specific variables marked `[UPDATE PER PRODUCT]` in both phases. See Section 5 for the full update checklist.

---

## SECTION 1 — PHASE 1: RESEARCH PROMPT

Copy this entire prompt into a new Claude chat. Fill in the variables, then run it.

---

```
RESEARCH PHASE — [YOUR_BRAND_NAME] Article

PRIMARY KEYWORD: [PRIMARY KEYWORD]
SECONDARY KEYWORD: [SECONDARY KEYWORD — optional, delete if not used]

TASK:
You are a research assistant preparing sources for a [YOUR_BRAND_NAME] health article. Your job is to find 9–12 high-quality sources that support an evidence-based article on the topic above, plus 2 pre-populated [YOUR_BRAND_NAME] brand sources.

For each source, find:
1. The direct URL to the specific page, study, or article
2. The key statistic, claim, or insight this source supports
3. A brief note on why this source is credible
4. For peer-reviewed studies: journal name, volume/issue, and year of publication

Output a structured RESEARCH PHASE OUTPUT block in exactly this format:

---
RESEARCH PHASE OUTPUT

source-1:
  url: [DIRECT URL]
  title: [Page or study title]
  journal: [Journal name, Vol. X, Year — for peer-reviewed studies; omit for non-journal sources]
  key-stat: [The specific stat or claim this source supports]
  credibility: [Why this is a reliable source]

source-2:
  url: [DIRECT URL]
  title: [Page or study title]
  journal: [Journal name, Vol. X, Year — for peer-reviewed studies; omit for non-journal sources]
  key-stat: [The specific stat or claim this source supports]
  credibility: [Why this is a reliable source]

[Continue for source-3 through source-10, adding source-11 and source-12 if strong additional sources exist]

source-business-homepage:
  url: https://www.[YOUR_DOMAIN]
  title: [YOUR_BRAND_NAME] — Official Website
  key-stat: [UPDATE PER PRODUCT: company credibility, certifications, manufacturing standards]
  credibility: Primary brand source

source-business-products:
  url: [UPDATE PER PRODUCT: full product page URL]
  title: [UPDATE PER PRODUCT: product name and page title]
  key-stat: [UPDATE PER PRODUCT: key product facts — bioavailability, dose, price, certifications]
  credibility: Primary product source
---

QUALITY STANDARDS FOR SOURCES:
- Prioritise: PubMed/NIH studies, systematic reviews, meta-analyses, Harvard Health, Sleep Foundation, CDC, Health Canada
- Acceptable: Major health institutions, peer-reviewed journals, government health bodies
- Avoid: Wikipedia, low-authority blogs, press releases, supplement company claims (other than [YOUR_BRAND_NAME]'s own pages)
- Stats must be specific: percentages, participant counts, timeframes, measurable outcomes
- All URLs must be direct links to the specific page — not homepages unless the homepage IS the source
- For every peer-reviewed study, record the journal name, volume/issue, and year — these are required for the Research References section in the final article
```

---

**After running Phase 1:** Copy the entire RESEARCH PHASE OUTPUT block. Paste it into the Phase 2 prompt where indicated.

---

## SECTION 2 — PHASE 2: ARTICLE PROMPT (v2.0)

Copy this entire prompt into a new Claude chat. Fill in all variables. Paste the Phase 1 output where indicated.

---

```
ARTICLE REQUIREMENTS

**1. Focus Keyword:**
Use the keyword exactly as provided: [PRIMARY KEYWORD] (Secondary: [SECONDARY KEYWORD])
Include it in the title, meta description, first 10% of content, at least one H2 or H3 heading, and distribute naturally throughout (approx. 1.2–1.4% density).


**2. Tone & Writing Style:**
Apply the [YOUR_BRAND_NAME] Brand Voice & Style Guide in full (available in Project Knowledge). Summary: evidence-based, accessible, honest, practical, non-promotional. Grade 7–8 readability. Clear, direct, helpful. Maximum 2–3 product mentions outside the dedicated business section. Never use absolute claims ("always", "never", "guaranteed", "works for everyone"). Always acknowledge limitations.


**3. Content Type:**
SEO long-form blog post designed to:
- Build topical authority
- Rank for long-tail and main keywords
- Drive conversions ethically


**4. Structure (follow exactly):**

METADATA BLOCK (plain text, output BEFORE the HTML body):
```
SEO Title: [title] ([character count] chars)
Meta Description: [description] ([character count] chars)
Suggested URL: /blogs/[product-category]/[keyword-slug-2026]
Tags: [5–8 relevant tags]
Featured Image Prompt: [MidJourney prompt — see Section 3 of skill for format]
Featured Image Alt Text: [descriptive alt text for SEO and accessibility]
```

HTML BODY (output immediately after metadata block):
- <h1> Article Title (with keyword, power word — max 60 chars for Google SEO)
- Short Intro (2–3 sentences, 1–2 stats, no more than 100 words)
- Key Takeaways box (5 bullet points, 1 stat each, 1 hyperlink each) — styled with inline CSS (see Section 4 of skill for the exact div format)
- Table of Contents (linked, 8–12 entries — place AFTER Key Takeaways box, BEFORE first H2 section)
- 5–7 main content sections with H2 headings
- DEDICATED BUSINESS SECTION (~200–250 words)
- FAQ section (5–6 questions with detailed 2–3 sentence answers)
- Conclusion (2–3 sentences with CTA)
- Research References (numbered list — see Section 11 of skill for exact format)
- Author Bio (standardised text — see Section 6 of skill)
- Medical + FDA/Health Canada disclaimers (see Section 6 of skill for exact text)

HEADING ACCURACY: Section headings must accurately reflect content. If you use comparison-style headings ("Top X", "Best Y", "Comparing X"), you MUST actually list/compare specific items with details. Otherwise use descriptive or question-based headings.

IMPORTANT: Weave [YOUR_BRAND_NAME] naturally into ALL relevant sections throughout — they must appear in every section where options, solutions, or providers are discussed, not just the dedicated business section.

Each section: 2–3 paragraphs (2–3 sentences each)

TITLE OUTPUT RULE (CRITICAL):
The SEO title MUST appear as the first element of the HTML output as an <h1> tag.
This is separate from the metadata note above. The <h1> is part of the article body and must not be omitted.

⛔ HARD LIMIT: 3500 WORDS MAXIMUM
- Stay UNDER 3500 words total
- Intro: ~100 words
- Main sections: ~1600–1900 words combined
- Business section: ~200–250 words
- FAQs: ~250–350 words
- Research References: ~150–250 words
- Every word must add value — be concise


**5. Research Requirements (STATISTICS THROUGHOUT — CRITICAL):**
You have been provided with research sources containing statistics and insights. Use them.

⚠️ STATS MUST APPEAR IN EVERY SECTION, NOT JUST TL;DR/FAQs:
- Include 12–18 specific statistics distributed EVENLY across the article
- EVERY paragraph in EVERY section MUST contain at least 1 number or stat
- Statistics: percentages (%), dollar amounts ($), growth rates, time metrics, benchmarks
- NO paragraph should be pure prose without a concrete number

STAT DISTRIBUTION TARGET:
- Intro: 1–2 stats
- TL;DR bullets: 5 stats (one per bullet)
- Section 1: 2–3 stats in paragraphs
- Section 2: 2–3 stats in paragraphs
- Section 3: 2–3 stats in paragraphs
- Section 4: 2–3 stats in paragraphs
- Sections 5–6 if present: 2–3 stats each
- FAQs: 2–3 stats across answers
- Conclusion: 1 stat

BULLET POINTS IN SECTIONS:
- Add a bullet point list to 2–3 sections (not all)
- Each bullet: a brief key fact with a number
- 3–4 bullets per section where used


**6. Hyperlink Requirements (CRITICAL — READ CAREFULLY):**
Every statistic, fact, claim, or data point MUST be hyperlinked to its source using a standard HTML anchor tag. Look up the URL for each source ID in the research phase output provided below and insert it directly — do not use placeholder formats.

FORMAT: <a href="URL" target="_blank" rel="noopener noreferrer">Anchor Text</a>

- Find the URL for each source ID in the research output (e.g. source-1, source-2, source-business-homepage, source-business-products) and insert it into the href attribute directly
- The Anchor Text is natural, readable text that forms the clickable link
- CRITICAL: When making claims about [YOUR_BRAND_NAME] (features, pricing, benefits, stats), you MUST link to source-business-homepage or source-business-products

HYPERLINK EXAMPLES (follow this pattern exactly):
- According to <a href="https://pubmed.ncbi.nlm.nih.gov/23691095/" target="_blank" rel="noopener noreferrer">a 2013 meta-analysis of 1,683 participants</a>, melatonin reduces sleep onset by 7 minutes vs. placebo.
- <a href="https://www.health.harvard.edu/staying-healthy/blue-light-has-a-dark-side" target="_blank" rel="noopener noreferrer">Harvard Health research</a> found that blue light suppresses melatonin for twice as long as green light.
- [YOUR_BRAND_NAME] uses <a href="https://www.[YOUR_DOMAIN]/products/liposomal-liquid-melatonin" target="_blank" rel="noopener noreferrer">liposomal technology achieving 80–95% bioavailability</a>.

HYPERLINK TARGETS:
- Intro: 1–2 hyperlinks
- Each main section: 2–3 hyperlinks
- Key Takeaway bullets: 1 hyperlink per bullet
- FAQ answers: 1 hyperlink per answer when citing data
- Conclusion: 1 hyperlink
- Overall target: 15–25 total hyperlinks


**7. Product Tie-Ins (CRITICAL):**
This article is for [YOUR_BRAND_NAME]. Their product must be woven throughout naturally.

REQUIREMENTS:
- Include [YOUR_BRAND_NAME] in EVERY section where options, solutions, or features are discussed
- The dedicated business section adds depth — it does not replace mentions elsewhere
- In comparison sections, list [YOUR_BRAND_NAME] as a named option with the same detail as any competitor
- Cite source-business-homepage or source-business-products when stating facts about [YOUR_BRAND_NAME]

BIOABSORB KEY FACTS — UPDATE THESE FOR EACH PRODUCT:
[UPDATE PER PRODUCT — replace the values below with the correct product's facts]
Current product (Liposomal Melatonin):
- Price: $29.99 / 100ml (100 servings)
- Dose: 1.5mg per full dropper (1ml); graduated dropper allows ~0.25mg increments
- Bioavailability: 80–95% vs. 15–20% for standard tablets
- Onset: 15–30 minutes vs. 60–90 minutes for standard tablets
- Certifications: GMP-certified, Health Canada-approved facility, Canada-manufactured
- Formulation: Non-GMO, vegan, gluten-free, no artificial flavours or colours, natural mixed berry flavour
- Third-party tested: every batch; COA available on request


**8. SEO Goals:**
- Rank for long-tail keywords
- Build topical authority within the product's health space
- Drive conversions ethically through education-first content
- Provide genuine value to health-conscious adults


**9. Audience:**
Adults researching health issues related to the article topic — particularly those dissatisfied with standard supplement forms or seeking to understand supplementation properly before purchasing. Health-conscious, responds to evidence and transparency over marketing claims. Both US and Canadian readers; default to US context where the two differ, but acknowledge Canada where relevant.


**10. Output format (CRITICAL):**
Output the article as a clean HTML fragment — no <html>, <head>, or <body> wrapper. Use only content tags: <h1>, <h2>, <h3>, <p>, <ul>, <ol>, <li>, <strong>, <em>, <a href>, <hr>.

The output must begin with the <h1> title tag:
<h1>Article Title Here</h1>
<p>Intro paragraph text here...</p>

imagePrompt notes: include one per section as an HTML comment immediately before the section's opening tag. Invisible on the page but preserved in [YOUR_CMS_PLATFORM] source for image generation reference.
Format: <!-- imagePrompt: your description here -->

Before the HTML body, output the metadata block as plain text (not rendered as HTML):
SEO Title: [title] ([character count] chars)
Meta Description: [description] ([character count] chars)
Suggested URL: /blogs/[product-category]/[keyword-slug-2026]
Tags: [5–8 relevant tags]
Featured Image Prompt: [MidJourney prompt]
Featured Image Alt Text: [alt text]

---

**Sources:**
[PASTE RESEARCH PHASE OUTPUT HERE]

---

**Focus Question:** [FOCUS QUESTION — delete this line if not used]

**Strategic Brief:** [STRATEGIC BRIEF — delete this line if not used]

**Business Section Guidance:** [BUSINESS SECTION GUIDANCE — delete this line if not used]

**CTA Guidance:** [CTA GUIDANCE — delete this line if not used]

---

⛔⛔⛔ FINAL CHECK BEFORE SUBMITTING: COUNT YOUR WORDS. MAXIMUM IS 3500. EXCEEDING THIS IS FAILURE. ⛔⛔⛔
Every word must count. Be concise.
```

---

## SECTION 3 — FEATURED IMAGE PROMPT (MidJourney)

After article generation, create a featured image using this MidJourney prompt template.

**Template:**
```
[Visual subject — abstract or conceptual, no people] representing [article topic],
[mood: calm / clinical / warm / scientific], [colour palette: muted blues and whites / warm neutrals / cool greens],
minimalist studio photography or digital art, professional health supplement aesthetic,
no text, no labels, no illustrations, no cartoon elements, 16:9 ratio, high resolution --ar 16:9 --v 6
```

**Examples:**

Timing article:
```
Soft glowing clock face dissolving into subtle moonlight, deep blue gradient background,
calm scientific mood, minimalist studio aesthetic, professional health content,
no text, no labels --ar 16:9 --v 6
```

Dosage article:
```
Single precise glass dropper with liquid drop suspended mid-fall, clean white background,
cool clinical lighting, minimalist product photography aesthetic, no text, no labels --ar 16:9 --v 6
```

Quality/buying guide:
```
Row of abstract supplement capsules with subtle quality certification symbols as background texture,
muted teal and white palette, professional healthcare aesthetic, no people, no text --ar 16:9 --v 6
```

**Alt text format:**
`[Topic] - [Visual element described] - [YOUR_BRAND_NAME]`
Example: `Melatonin timing - glowing clock dissolving into moonlight - [YOUR_BRAND_NAME]`

---

## SECTION 4 — KEY TAKEAWAYS BOX (Inline CSS)

Use this exact div format for the Key Takeaways box. [YOUR_CMS_PLATFORM] does not support external stylesheets for blog content — inline CSS is required.

```html
<div style="background:#f0f7ff;border-left:4px solid #2563eb;padding:20px 24px;margin:28px 0;border-radius:4px;">
<h2 style="margin-top:0;font-size:1.1em;text-transform:uppercase;letter-spacing:0.05em;color:#1e40af;">Key Takeaways</h2>
<ul style="margin:0;padding-left:20px;">
<li style="margin-bottom:8px;">[Takeaway 1 with hyperlinked stat]</li>
<li style="margin-bottom:8px;">[Takeaway 2 with hyperlinked stat]</li>
<li style="margin-bottom:8px;">[Takeaway 3 with hyperlinked stat]</li>
<li style="margin-bottom:8px;">[Takeaway 4 with hyperlinked stat]</li>
<li style="margin-bottom:8px;">[Takeaway 5 with hyperlinked stat]</li>
</ul>
</div>
```

Each bullet must contain one hyperlinked external citation. The Key Takeaways box comes immediately after the intro paragraph and before the Table of Contents.

---

## SECTION 5 — SWITCHING PRODUCTS: UPDATE CHECKLIST

When writing for any product other than Liposomal Melatonin, update ALL of the following before running either prompt:

**In Phase 1 (Research Prompt):**
- [ ] `source-business-products` → update URL to the correct product page
- [ ] `source-business-products` key-stat → update with correct product's key facts

**In Phase 2 (Article Prompt):**
- [ ] Section 7 "[YOUR_BRAND_NAME] Key Facts" → replace all values with the new product's facts
- [ ] source-business-products URL → confirm it matches Phase 1

**Product page URLs (current):**
- Liposomal Melatonin: `https://www.[YOUR_DOMAIN]/products/liposomal-liquid-melatonin`
- Other products: check `https://www.[YOUR_DOMAIN]` — confirm URL before use

⚠️ **URL slug ≠ product page title.** [YOUR_CMS_PLATFORM] URL slugs are not always updated when products are renamed or reformulated. Always verify the product page title (visible in the browser tab and `<h1>`) when referencing a product in article copy — never rely on the URL slug. Example: a product URL containing "powder" and "ascorbic-acid-crystals" had a page title of "Liposomal Vitamin C Capsules". The page title is the authoritative name.

**Product facts to find for each new product:**
- Price and serving size
- Key active ingredient and dose per serving
- Bioavailability claim (and comparison to standard forms)
- Onset time if relevant
- Certifications (GMP, Health Canada, third-party testing)
- Formulation attributes (non-GMO, vegan, allergen-free, etc.)
- Flavour / format

---

## SECTION 6 — AUTHOR BIO AND DISCLAIMERS (Required — E-E-A-T and Legal)

Include these standardised blocks at the end of every article, in the order shown below. Do not modify the text.

### Order at end of article:
1. Conclusion
2. Research References (see Section 11)
3. Author Bio
4. Disclaimers

### Author Bio HTML:
```html
<h3>About the Author</h3>
<p>David Kimbell is a health writer, digital entrepreneur and former aerospace engineer, based in Ottawa, Canada. He loves translating complex science into clear, actionable guidance for consumers seeking evidence-based solutions.</p>
```

### Disclaimers HTML:
```html
<hr>
<h3>Important Disclaimers</h3>
<p><strong>Medical Disclaimer:</strong> This article provides educational information only and is not intended as medical advice. Always consult with a qualified healthcare provider before starting any new supplement, especially if you have existing health conditions, take medications, or are pregnant or nursing.</p>
<p><strong>FDA/Health Canada Statement:</strong> These statements have not been evaluated by the Food and Drug Administration or Health Canada. This product is not intended to diagnose, treat, cure, or prevent any disease.</p>
```

---

## SECTION 7 — COMPLETE ARTICLE STRUCTURE (Final Order)

Every article must follow this exact order:

```
[Plain text metadata block]
SEO Title: ...
Meta Description: ...
Suggested URL: ...
Tags: ...
Featured Image Prompt: ...
Featured Image Alt Text: ...

[HTML body begins here]

<h1>Article Title</h1>

<p>Intro (2–3 sentences, 1–2 stats, max 100 words)</p>

[Key Takeaways box — inline CSS div]
(5 bullets, 1 stat + 1 hyperlink each)

<h2>Table of Contents</h2>
(linked list, 8–12 entries, placed AFTER Key Takeaways, BEFORE first content section)

<!-- imagePrompt: description -->
<h2>Section 1</h2>
(2–3 paragraphs, 2–3 stats, 2–3 hyperlinks)

<!-- imagePrompt: description -->
<h2>Section 2</h2>
...

[5–7 main sections total]

<!-- imagePrompt: description -->
<h2>[YOUR_BRAND_NAME] [Product] — [Headline]</h2>
(Dedicated business section ~200–250 words)

<h2>Frequently Asked Questions</h2>
<h3>Question 1?</h3>
<p>Answer (2–3 sentences, 1 hyperlink where citing data)</p>
...
(5–6 questions total)

<h2>Conclusion</h2>
<p>(2–3 sentences, 1 stat, CTA linking to product page)</p>

<h2>Research References</h2>
(numbered list — see Section 11 for format)

<h3>About the Author</h3>
<p>David Kimbell bio text...</p>

<hr>
<h3>Important Disclaimers</h3>
<p><strong>Medical Disclaimer:</strong> This article provides educational information only and is not intended as medical advice. Always consult with a qualified healthcare provider before starting any new supplement, especially if you have existing health conditions, take medications, or are pregnant or nursing.</p>
<p><strong>FDA/Health Canada Statement:</strong> These statements have not been evaluated by the Food and Drug Administration or Health Canada. This product is not intended to diagnose, treat, cure, or prevent any disease.</p>
```

---

## SECTION 8 — INTERNAL LINKING (Post-Generation Step)

Internal links are added **after** article generation, as a separate step before publishing. They are not part of the article prompt output.

**Why separate:** Internal linking requires knowing which articles are published and what their live URLs are. This information lives in Project Knowledge (internal linking spreadsheet), not in the article prompt.

**Process:**
1. Generate article (Phase 2)
2. Run link checker (see Section 9)
3. Add internal links using published URL list from Project Knowledge
4. Publish to [YOUR_CMS_PLATFORM]

**Placement guidance:**
- Add 3–6 internal links per article
- Include at least 1 link to the most closely associated [YOUR_BRAND_NAME] product page
- Include at least 2 links to other published [YOUR_BRAND_NAME] articles in the same cluster (where they exist)
- Place at natural sentence endings or after relevant claims
- Link anchor text should be descriptive of the destination article
- Do not force internal links — only add where the reference is genuinely relevant
- Internal links do NOT require `target="_blank"` (same-site navigation)

---

## SECTION 9 — POST-GENERATION QA: LINK CHECKER

After Phase 2 generation and before publishing, run the link checker skill.

**Installed at:** `/mnt/skills/user/article-link-checker/SKILL.md`

**Triggers:** "check the links", "verify links", "run the link checker", "are all the links working"

**What it checks:**
- Every unique external URL is live
- Source content matches what the article claims
- Anchor text accurately represents the linked page
- Internal [YOUR_BRAND_NAME] links checked against Project Knowledge

**Output:** Structured audit report — ✅ / ⚠️ / ❌ per URL, action items, and READY TO PUBLISH / NEEDS FIXES verdict.

**Do not skip this step.** The first test article had a conflicting stat attributed to the wrong source. The link checker catches this class of error.

---

## SECTION 10 — KEY PRINCIPLES (DO NOT REPEAT THESE MISTAKES)

1. **HTML first, always.** Never output markdown if the destination is [YOUR_CMS_PLATFORM]. Markdown converters break links.

2. **Resolve source IDs to URLs at generation time.** Never use placeholder formats. If post-processing is skipped, the article has dead links.

3. **The `<h1>` must be in the article body.** If the title only appears in the metadata note, it gets stripped when the header block is removed. It must be the first tag in the HTML output.

4. **imagePrompts go in HTML comments.** `<!-- imagePrompt: ... -->` is invisible on the page but survives in [YOUR_CMS_PLATFORM] source. This is the correct approach.

5. **Link bioavailability claims to the product page, not the homepage.** The homepage doesn't contain the stat. This looks thin if anyone checks.

6. **Internal links are a separate post-generation step.** Don't try to bake them into the article prompt — the prompt doesn't know which articles exist yet.

7. **Run the link checker before publishing.** It catches wrong stats, dead URLs, and anchor text mismatches.

8. **The research prompt's business source entries are product-specific.** When switching products, update `source-business-products` URL and key facts before running Phase 1.

9. **TOC comes after Key Takeaways, not before.** The Key Takeaways box is a reader hook — it leads. The TOC follows for navigation.

10. **Validate stats against their cited source.** StatPearls, PubMed, and similar sources are authoritative but get misquoted. Always check that the stat in the article matches the stat in the source.

11. **Research References must include journal metadata for peer-reviewed sources.** Title alone is insufficient — journal name, volume, and year are required. This information must be captured in Phase 1 and carried through to the final article.

---

## SECTION 11 — RESEARCH REFERENCES (Required Section)

Every article must include a Research References section immediately after the Conclusion and before the Author Bio.

**Purpose:** Establishes E-E-A-T credibility, satisfies Google's quality signals for health content, and supports AEO/AI citation by making sources machine-readable and human-verifiable.

**Format rules:**
- Numbered ordered list (`<ol>`)
- Include only sources actually cited in the article body (not all Phase 1 sources if some were unused)
- Exclude source-business-homepage and source-business-products (brand sources, not research)
- Order: peer-reviewed studies first, then institutional sources, then other sources

**HTML format:**
```html
<h2>Research References</h2>
<ol>
  <li><strong>[Study or article title]</strong>. <em>[Journal Name]</em>, Vol. [X] ([Year]). [One sentence describing what this research found and what claim in the article it supports.]</li>
  <li><strong>[Institutional article title]</strong>. [Organisation Name] ([Year]). [One sentence describing the key finding cited.]</li>
</ol>
```

**Example entries:**

Peer-reviewed study:
```html
<li><strong>Exogenous melatonin for sleep disorders in neurological diseases: a meta-analysis of randomized controlled trials</strong>. <em>Neurological Sciences</em>, Vol. 37 (2016). Found that melatonin supplementation significantly reduced sleep onset latency and improved sleep quality across multiple neurological conditions.</li>
```

Institutional source:
```html
<li><strong>Melatonin: What You Need to Know</strong>. National Institutes of Health — National Center for Complementary and Integrative Health (2022). Overview of melatonin's safety profile, typical dosage ranges, and evidence base for sleep support.</li>
```

**What to do when journal metadata is missing:** If Phase 1 did not return journal/volume/year for a peer-reviewed source, do not fabricate it. Flag the entry with `[journal details not confirmed]` and verify before publishing.

---

## SECTION 12 — CONTENT QUALITY REFERENCE

Use this section to calibrate quality during article generation. These patterns distinguish content that builds authority from content that merely fills word count.

---

### 12.1 Section Progression Pattern

Well-structured [YOUR_BRAND_NAME] articles follow a deliberate content arc across their 5–7 main sections:

| Position | Type | Purpose | Example heading |
|----------|------|---------|----------------|
| Early (Sections 1–2) | **Foundational** | Define key terms, establish scientific context, build reader knowledge base | "How Melatonin Works in the Body" |
| Middle (Sections 3–4) | **Practical/Application** | Specific protocols, step-by-step guidance, dosing with actual numbers | "Melatonin Protocol for Night Shift Workers" |
| Later (Section 5) | **Advanced/Nuance** | Special cases, troubleshooting, optimisation, edge conditions | "When to Adjust Your Protocol" |
| Natural placement (Sections 5–7) | **Product Integration** | One section. Titled with a benefit, not the product name. | "The Absorption Advantage: Getting More from Less" — NOT "[YOUR_BRAND_NAME] Liposomal Melatonin" |

**The product integration section is educational, not promotional.** It uses the product as an example of a solution class — not as the subject of a sales pitch. If the section reads like an ad, rewrite it from the reader's perspective: "What does better absorption mean for my results?"

---

### 12.2 Numbered Sections Rule

Use sequential flat numbering for main sections: 1, 2, 3, 4...

Do NOT use subsection numbering (1.1, 1.2, 2.1). Subsection numbers create visual complexity, make TOC entries hard to scan, and signal to readers that the structure is hierarchical when it should feel like a guided journey.

---

### 12.3 Introduction Quality — Annotated Examples

**✅ Strong Introduction**

```
You just finished a 12-hour night shift. It's 8 AM and sunny, but you need 
to sleep. Your body screams "WAKE UP!" while your exhausted mind begs for 
rest. This daily battle isn't just uncomfortable—it's dangerous.

Shift work sleep disorder affects 10–38% of shift workers, increasing risks 
of cardiovascular disease, diabetes, and accidents. Yet most shift workers 
struggle alone, relying on caffeine to stay awake and hoping for exhaustion 
to bring sleep.

This guide provides evidence-based melatonin protocols specifically for shift 
workers—whether you work permanent nights, rotating shifts, or 12-hour 
schedules. You'll learn optimal dosing by shift type, timing strategies that 
work with your schedule, and supporting strategies beyond melatonin alone.
```

**Why it works:**
- Opens with a scene that earns attention in two sentences — specific, sensory, relatable
- Follows immediately with a stat that validates the problem (10–38%, not "many people")
- Delivers a specific promise (protocols by shift type) — the reader knows exactly what they're getting
- Total length: under 100 words

**❌ Weak Introduction**

```
Melatonin is a popular supplement that many people use for sleep. Shift workers 
often have trouble sleeping due to their schedules. This article will discuss 
how melatonin can help shift workers sleep better. We will cover dosing, timing, 
and other helpful tips.
```

**Why it fails:** Generic opening, no data, vague promise ("other helpful tips"), no compelling reason to continue reading.

---

### 12.4 Section Content Quality — Annotated Examples

**✅ Strong Protocol Section**

```html
<h2 id="night-shift-protocol">4. Melatonin Protocol for Night Shift Workers</h2>

<p><strong>Goal:</strong> Shift circadian rhythm to align with night schedule.</p>

<p><strong>Protocol:</strong></p>
<ul>
  <li>Dose: 1–3mg (start low, titrate up over 3–4 nights)</li>
  <li>Timing: 30–60 minutes before your daytime sleep window</li>
  <li>Light management: Wear blue-light blocking glasses during morning commute home</li>
</ul>

<p><strong>What to expect:</strong></p>
<ul>
  <li>Week 1: Difficult adjustment — melatonin helps but adjustment is incomplete</li>
  <li>Weeks 2–3: Noticeable improvement in sleep onset and duration</li>
  <li>Week 4+: Body partially adjusted; most shift workers report stable daytime sleep</li>
</ul>
```

**Why it works:** States the goal. Gives actual numbers (not "an appropriate amount"). Sets a realistic timeline. Treats the reader as capable of following a specific protocol.

**❌ Weak Protocol Section**

```html
<h2>4. Using Melatonin for Night Shifts</h2>
<p>If you work night shifts, melatonin can help you sleep better during the day. 
Take it before you go to sleep and make sure your room is dark. Many people find 
that melatonin works well for them. You should try different doses to see what 
works best.</p>
```

**Why it fails:** No dose. No timing. "Try different doses" is not guidance. Adds no value beyond what anyone could guess.

---

### 12.5 FAQ Quality — Annotated Examples

**✅ Strong FAQ**

```
Q: Should I take melatonin on my days off from shift work?

A: It depends on your strategy. If you're maintaining your night schedule on 
days off, take melatonin at the same time as work nights. If flipping back to 
a day schedule, take it at your intended day-schedule bedtime instead. Most 
sleep specialists recommend maintaining the night schedule even on days off — 
repeatedly flipping between schedules strains your circadian system more than 
staying consistent.
```

**Why it works:** Answers a genuinely specific question shift workers ask. Presents two real scenarios. Gives a recommendation with a reason, not just "it depends."

**❌ Weak FAQ**

```
Q: Is melatonin good?

A: Yes, melatonin is generally considered safe and effective for most people when 
used properly. Many studies have shown that it can help with sleep. However, you 
should talk to your doctor before starting any supplement.
```

**Why it fails:** The question isn't one anyone types into Google. The answer is generic, adds no information, and the doctor disclaimer at the end is boilerplate that signals the writer ran out of things to say.

---

### 12.6 Application Note

These patterns apply to all [YOUR_BRAND_NAME] articles regardless of product. The product changes; the quality bar does not. When in doubt, ask: if a reader searched for this question and landed on this section, would they leave with something they couldn't have worked out on their own? If no — rewrite the section.
