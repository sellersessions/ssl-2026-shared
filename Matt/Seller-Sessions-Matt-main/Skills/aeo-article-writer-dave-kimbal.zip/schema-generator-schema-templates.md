# Schema Templates Reference

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


Complete JSON-LD templates for all [YOUR_BRAND_NAME] schema types.

## Universal Schema (ALL Articles)

### Article
```json
{
  "@type": "Article",
  "headline": "[Article Title]",
  "description": "[Meta description]",
  "image": "[Featured image URL]",
  "author": {
    "@type": "Person",
    "name": "Dave Kimbell, for [YOUR_BRAND_NAME]"
  },
  "publisher": {
    "@type": "Organization",
    "name": "[YOUR_BRAND_NAME]",
    "logo": {
      "@type": "ImageObject",
      "url": "https://cdn.shopify.com/s/files/1/0364/0528/0900/files/logo.jpg?v=1613761415"
    }
  },
  "datePublished": "[YYYY-MM-DD]",
  "dateModified": "{{ article.updated_at | date: '%Y-%m-%d' }}",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "[Full article URL]"
  }
}
```

### BreadcrumbList
```json
{
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://www.[YOUR_DOMAIN]"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "[Product] Guide",
      "item": "https://www.[YOUR_DOMAIN]/blogs/[product-slug]"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "[Article Title]",
      "item": "[Full article URL]"
    }
  ]
}
```

### MedicalWebPage (Base)
```json
{
  "@type": "MedicalWebPage",
  "mainContentOfPage": {
    "@type": "WebPageElement",
    "cssSelector": ".article-content"
  },
  "audience": {
    "@type": "MedicalAudience",
    "audienceType": "Patient"
  },
  "lastReviewed": "{{ article.updated_at | date: '%Y-%m-%d' }}",
  "specialty": {
    "@type": "MedicalSpecialty",
    "name": "[Sleep Medicine / Nutritional Medicine / Orthopedic Medicine / etc]"
  }
}
```

### MedicalWebPage (With Health Condition)
```json
{
  "@type": "MedicalWebPage",
  "mainContentOfPage": {
    "@type": "WebPageElement",
    "cssSelector": ".article-content"
  },
  "audience": {
    "@type": "MedicalAudience",
    "audienceType": "Patient",
    "healthCondition": {
      "@type": "MedicalCondition",
      "name": "[Insomnia / DSPS / Vitamin D Deficiency / etc]"
    }
  },
  "lastReviewed": "{{ article.updated_at | date: '%Y-%m-%d' }}",
  "specialty": {
    "@type": "MedicalSpecialty",
    "name": "[Specialty]"
  }
}
```

### MedicalWebPage (With Age Targeting)
```json
{
  "@type": "MedicalWebPage",
  "mainContentOfPage": {
    "@type": "WebPageElement",
    "cssSelector": ".article-content"
  },
  "audience": {
    "@type": "MedicalAudience",
    "audienceType": "Patient",
    "suggestedMinAge": 65
  },
  "lastReviewed": "{{ article.updated_at | date: '%Y-%m-%d' }}",
  "specialty": {
    "@type": "MedicalSpecialty",
    "name": "[Specialty]"
  }
}
```

### Product (Generic Template)
```json
{
  "@type": "Product",
  "name": "[Product Name]",
  "image": "[Product image URL]",
  "description": "[Product description]",
  "sku": "[SKU]",
  "brand": {
    "@type": "Brand",
    "name": "[YOUR_BRAND_NAME]"
  },
  "category": "Health & Beauty > Vitamins & Supplements > [Subcategory]",
  "additionalProperty": [
    {
      "@type": "PropertyValue",
      "name": "Active Ingredient",
      "value": "[Ingredient]"
    },
    {
      "@type": "PropertyValue",
      "name": "Delivery Method",
      "value": "[Liposomal Liquid/Capsule/Tablet/etc]"
    }
  ],
  "offers": {
    "@type": "Offer",
    "url": "[Product URL]",
    "priceCurrency": "USD",
    "price": "[Price]",
    "availability": "https://schema.org/InStock",
    "priceValidUntil": "2026-12-31",
    "shippingDetails": {
      "@type": "OfferShippingDetails",
      "shippingDestination": {
        "@type": "DefinedRegion",
        "addressCountry": "US"
      }
    }
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "[Rating]",
    "reviewCount": "[Count]",
    "bestRating": "5",
    "worstRating": "1"
  }
}
```

### FAQPage
```json
{
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "[Question text]",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "[Answer text]"
      }
    }
  ]
}
```

### SpeakableSpecification
```json
{
  "@type": "SpeakableSpecification",
  "cssSelector": [
    ".article-content h2",
    ".article-content .key-takeaways"
  ]
}
```

## Conditional Schema

### HowTo
```json
{
  "@type": "HowTo",
  "name": "[Protocol/procedure name]",
  "description": "[What the procedure achieves]",
  "step": [
    {
      "@type": "HowToStep",
      "text": "[Step 1 instruction]"
    },
    {
      "@type": "HowToStep",
      "text": "[Step 2 instruction]"
    }
  ]
}
```

### ItemList (Comparison/Ranking)
```json
{
  "@type": "ItemList",
  "name": "[List name - e.g., 'Vitamin D Supplement Forms Ranked']",
  "description": "[What is being compared]",
  "itemListOrder": "https://schema.org/ItemListOrderDescending",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@type": "Thing",
        "name": "[Item name]",
        "description": "[Bioavailability, absorption time, key benefits]",
        "url": "[Optional anchor URL to section]"
      }
    },
    {
      "@type": "ListItem",
      "position": 2,
      "item": {
        "@type": "Thing",
        "name": "[Item name]",
        "description": "[Details]",
        "url": "[Optional URL]"
      }
    }
  ]
}
```

### ItemList (Hub Article - Related Content)
```json
{
  "@type": "ItemList",
  "name": "[Product] Content Hub: Complete Article Series",
  "description": "[Description of content hub]",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@type": "Article",
        "name": "[Related Article Title]",
        "url": "[Related Article URL]"
      }
    }
  ]
}
```

### Table
```json
{
  "@type": "Table",
  "about": "[What the table shows - e.g., 'Vitamin D dosage ranges by age']",
  "description": "[Optional: Additional detail about table contents]"
}
```

### SearchAction (Pillar Articles Only)
```json
{
  "@type": "WebSite",
  "url": "https://www.[YOUR_DOMAIN]",
  "potentialAction": {
    "@type": "SearchAction",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": "https://www.[YOUR_DOMAIN]/search?q={search_term_string}"
    },
    "query-input": "required name=search_term_string"
  }
}
```

## Complete Example: Pillar Article

Full schema for a pillar article with all components:

```json
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Article",
      "headline": "Vitamin D for Health: Complete Evidence-Based Guide 2026",
      "description": "Comprehensive guide to vitamin D benefits, dosing, and optimization.",
      "image": "https://cdn.shopify.com/s/files/1/0364/0528/0900/files/vitamin-d-guide.png",
      "author": {
        "@type": "Person",
        "name": "Dave Kimbell, for [YOUR_BRAND_NAME]"
      },
      "publisher": {
        "@type": "Organization",
        "name": "[YOUR_BRAND_NAME]",
        "logo": {
          "@type": "ImageObject",
          "url": "https://cdn.shopify.com/s/files/1/0364/0528/0900/files/logo.jpg?v=1613761415"
        }
      },
      "datePublished": "2026-02-01",
      "dateModified": "{{ article.updated_at | date: '%Y-%m-%d' }}",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": "https://www.[YOUR_DOMAIN]/blogs/vitamin-d/complete-guide"
      }
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://www.[YOUR_DOMAIN]"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Vitamin D Guide",
          "item": "https://www.[YOUR_DOMAIN]/blogs/vitamin-d"
        },
        {
          "@type": "ListItem",
          "position": 3,
          "name": "Vitamin D for Health: Complete Guide",
          "item": "https://www.[YOUR_DOMAIN]/blogs/vitamin-d/complete-guide"
        }
      ]
    },
    {
      "@type": "MedicalWebPage",
      "mainContentOfPage": {
        "@type": "WebPageElement",
        "cssSelector": ".article-content"
      },
      "audience": {
        "@type": "MedicalAudience",
        "audienceType": "Patient"
      },
      "lastReviewed": "{{ article.updated_at | date: '%Y-%m-%d' }}",
      "specialty": {
        "@type": "MedicalSpecialty",
        "name": "Nutritional Medicine"
      }
    },
    {
      "@type": "WebSite",
      "url": "https://www.[YOUR_DOMAIN]",
      "potentialAction": {
        "@type": "SearchAction",
        "target": {
          "@type": "EntryPoint",
          "urlTemplate": "https://www.[YOUR_DOMAIN]/search?q={search_term_string}"
        },
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "ItemList",
      "name": "Vitamin D Content Hub: Complete Article Series",
      "description": "Comprehensive vitamin D education series",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "item": {
            "@type": "Article",
            "name": "Vitamin D Dosage Guide",
            "url": "https://www.[YOUR_DOMAIN]/blogs/vitamin-d/dosage-guide"
          }
        }
      ]
    },
    {
      "@type": "SpeakableSpecification",
      "cssSelector": [
        ".article-content h2",
        ".article-content .key-takeaways"
      ]
    },
    {
      "@type": "Product",
      "name": "Liposomal Vitamin D3",
      "image": "https://cdn.shopify.com/s/files/1/0364/0528/0900/products/vitamin-d3.jpg",
      "description": "Premium Liposomal Vitamin D3 for enhanced absorption.",
      "sku": "VITAMIND3001",
      "brand": {
        "@type": "Brand",
        "name": "[YOUR_BRAND_NAME]"
      },
      "category": "Health & Beauty > Vitamins & Supplements > Vitamin D",
      "additionalProperty": [
        {
          "@type": "PropertyValue",
          "name": "Active Ingredient",
          "value": "Vitamin D3 (Cholecalciferol)"
        },
        {
          "@type": "PropertyValue",
          "name": "Delivery Method",
          "value": "Liposomal Liquid"
        }
      ],
      "offers": {
        "@type": "Offer",
        "url": "https://www.[YOUR_DOMAIN]/products/liposomal-vitamin-d3",
        "priceCurrency": "USD",
        "price": "24.99",
        "availability": "https://schema.org/InStock",
        "priceValidUntil": "2026-12-31",
        "shippingDetails": {
          "@type": "OfferShippingDetails",
          "shippingDestination": {
            "@type": "DefinedRegion",
            "addressCountry": "US"
          }
        }
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "5",
        "reviewCount": "3",
        "bestRating": "5",
        "worstRating": "1"
      }
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "What does vitamin D do in the body?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Vitamin D supports bone health, immune function, and calcium absorption."
          }
        }
      ]
    }
  ]
}
```
