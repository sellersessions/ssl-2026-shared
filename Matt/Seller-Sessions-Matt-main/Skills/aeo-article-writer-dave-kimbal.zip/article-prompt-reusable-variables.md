# [YOUR_BRAND_NAME] Article Prompt — Reusable Variables

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---

**Purpose:** Defines the fixed variables used in every [YOUR_BRAND_NAME] article prompt run.
These values do not change between articles. Per-article variables are defined separately at runtime.
**Last Updated:** 2026-03-05

---

## businessInfo

| Field | Value |
|---|---|
| Company Name | [YOUR_BRAND_NAME] |
| Website | https://[YOUR_DOMAIN] |
| Product Page | https://www.[YOUR_DOMAIN]/products/liposomal-liquid-melatonin |
| Product Name | Liposomal Liquid Melatonin |
| Price | $29.99 / 100ml |
| Dose | 1.5mg per full dropper (1ml) |
| Servings Per Bottle | 100 |
| Bioavailability | 80–95% (vs. 15–20% for standard tablets) |
| Onset Time | 15–30 minutes (vs. 60–90 minutes for standard tablets) |
| Certifications | GMP-certified; Health Canada-approved facility |
| Manufacturing | Canada |
| Formulation | Non-GMO, gluten-free, nut-free, dairy-free (vegan), corn-free |
| Flavour | Natural mixed berry |
| Dropper | Graduated; allows precise dosing from 0.5mg to 3mg in ~0.25mg increments |
| Third-Party Testing | Every batch tested by independent laboratories; COA available on request |

### Key Differentiators (for use in article copy)
- Liposomal delivery achieves 80–95% bioavailability vs. 15–20% for standard tablets — a 4–5x improvement
- Higher absorption means effective results at lower doses, reducing risk of grogginess and side effects
- Graduated dropper enables dose titration that tablets and gummies cannot match
- Fast 15–30 minute onset is clinically relevant for jet lag and flexible sleep timing
- Canadian GMP manufacturing with Health Canada approval — a meaningful credibility signal for both US and Canadian audiences
- Clean label: no artificial colours, flavours, or common allergens

---

## audience

Adults researching sleep issues who are either:
- Dissatisfied with standard melatonin (poor results, morning grogginess, uncertainty about dosing)
- Actively trying to understand supplementation properly before purchasing
- Health-conscious consumers who respond to evidence and transparency over marketing claims
- Includes both first-time melatonin users and experienced users who want better results

**Reading level target:** Grade 7–8 (accessible but not condescending)
**Assumed intelligence:** High — readers can handle mechanism explanations if written clearly

---

## tone

Refer to the **[YOUR_BRAND_NAME] Brand Voice & Style Guide** in Project Knowledge for the full specification.

### Summary for quick reference:
- **Voice:** Knowledgeable guide — the well-read friend who did the research so the reader doesn't have to
- **Not:** Academic journal, marketing hype, or generic health blog
- **Primary attribute:** Evidence-based — every claim backed by research or data, with specific numbers
- **Secondary attributes:** Accessible, honest, practical, non-promotional
- **Promotional restraint:** Maximum 2–3 product mentions per article; education always comes first
- **Absolute claims:** Never use "always", "never", "guaranteed", "works for everyone"
- **Limitations:** Always acknowledge them — builds more trust than hiding them

---

## location

- **Primary market:** United States
- **Secondary market:** Canada
- **Manufacturing signal:** Canadian GMP facility with Health Canada approval — reference where relevant as a quality and credibility indicator, particularly for Canadian readers
- **Geo-specific note:** Where dosing guidelines, regulatory context, or availability differ between US and Canada, acknowledge both. Default to US context when only one can be used.

---

## Notes for prompt execution

1. When `businessInfo` is referenced in the article prompt, draw from the table above.
2. When `tone` is referenced, apply the Brand Voice & Style Guide from Project Knowledge in full — this summary is a reminder, not a replacement.
3. `audience` and `location` inform framing, reading level, and any geographic context woven into the article.
4. These variables are fixed. Do not modify them at runtime — per-article variables (keyword, sources, brief, etc.) are specified separately.
