You are helping create "Key Takeaways" snippets for a set of [YOUR_BRAND_NAME] blog posts. These snippets are designed for AEO (Answer Engine Optimization) purposes and will be copy-pasted directly into [YOUR_CMS_PLATFORM] blog posts using the HTML editor.

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


## Your Task

For each blog post URL provided at the end of this prompt:
1. Fetch the live content of the page
2. Read the article carefully
3. Draft a Key Takeaways snippet based on the article's actual published content
4. Format it exactly as specified below

If you cannot access the content of any URL, stop and say so before proceeding.

---

## Content Guidelines

Each snippet should contain 4–6 bullet points that:
- Summarise the most important, actionable points from the article
- Are written as complete, standalone sentences (a reader should understand each point without having read the article)
- Prioritise specific facts, numbers, protocols, and evidence-based claims over vague generalities
- Are accurate to what the article actually says — do not invent or embellish claims
- Are concise but substantive — aim for one clear idea per bullet, expressed in 20–35 words

---

## Formatting Requirements

Use this exact HTML for every snippet, with no deviations:
```html
<div style="border: 1px solid #d0d0d0; background-color: #f9f9f9; border-radius: 6px; padding: 18px 22px; margin: 24px 0;">
  <h4 style="margin-top: 0; margin-bottom: 10px; font-size: 1em; letter-spacing: 0.03em; text-transform: uppercase;">Key Takeaways</h4>
  <ul style="margin: 0; padding-left: 20px;">
    <li style="margin-bottom: 8px;">[Bullet point text]</li>
    <li style="margin-bottom: 8px;">[Bullet point text]</li>
    <li style="margin-bottom: 8px;">[Bullet point text]</li>
    <li style="margin-bottom: 8px;">[Bullet point text]</li>
    <li style="margin-bottom: 0;">[Final bullet point text — note margin-bottom: 0 on the last item only]</li>
  </ul>
</div>
```

Important formatting rules:
- Use `<h4>` for the heading, not `<h3>`, `<h2>`, or `<p><strong>`
- The label is "Key Takeaways" — not "TL;DR" or any other label
- Every `<li>` except the last uses `margin-bottom: 8px`
- The last `<li>` always uses `margin-bottom: 0`
- All inline styles must be preserved exactly as shown — do not move any styling to a stylesheet

---

## Output Format

- Label each snippet clearly with the article title and/or URL so it's easy to match to the right post
- Present them in the same order as the URLs provided
- Output only the labelled HTML snippets — no additional commentary between them (a brief note at the very end is fine if needed)

---

## Implementation Notes for the Person Pasting These In

- **Placement:** Insert the snippet immediately after the opening paragraph or introduction, before the first `<h2>` section heading — do not place it at the bottom of the post
- **[YOUR_CMS_PLATFORM] editor:** Switch to HTML view (the `<>` button in the blog post editor) before pasting — pasting into the visual editor will cause the HTML tags to appear as literal text
- **Validation:** After pasting and saving, preview the post to confirm the box renders correctly before moving to the next article

---

## Blog Post URLs
[INSERT BULLETED OR NUMBERED LIST OF BLOG POST URLS]