# [YOUR_BRAND_NAME] Article Writing SOP

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---

**Version 1.1 — March 2026**
For use across all three [YOUR_BRAND_NAME] blogs.

---

## Purpose

This SOP governs the research and writing phases for any new article on a [YOUR_BRAND_NAME] blog. It applies to both cluster articles (part of a structured product content hub) and standalone news blog articles. Following this process produces articles that are evidence-based, citation-rich, SEO-optimized, and ready to paste directly into [YOUR_CMS_PLATFORM].

---

## The Three [YOUR_BRAND_NAME] Blogs

| Blog | Purpose | URL Pattern |
|------|---------|-------------|
| Melatonin | Cluster articles around the melatonin supplement hub | `/blogs/melatonin/` |
| Vitamin C | Cluster articles around the Vitamin C supplement hub | `/blogs/vitamin-c/` |
| News | Standalone health & wellness articles | `/blogs/news/` |

---

## Article Types

### Cluster Article
An article that belongs to a structured content hub around a specific [YOUR_BRAND_NAME] product. Cluster articles are planned as a group before any individual article is written, using the Site Mapping SOP (Phase 0 below). **Keywords, titles, URL slugs, tags, and internal linking structure for cluster articles are all defined at site mapping time** and saved to Project Knowledge. Do not invent or redefine these at article-writing time.

### Standalone Article
An article in the news blog that is not part of a product cluster. No site mapping is required. **Keywords for standalone articles come from the PAA Extractor SOP** — the exact PAA question is used verbatim as the primary keyword and SEO title. The writing workflow is otherwise identical to cluster articles.

---

## Full Workflow Overview

```
[Cluster only] Phase 0 — Site Mapping
         ↓
[Cluster only] Phase 0b — URL Placeholders
         ↓
Phase 1 — Keyword & Topic Definition
         ↓
Phase 2 — Research (Claude — skill invocation)
         ↓
Phase 3 — Article Generation (Claude — may run with Phase 2)
         ↓
Phase 4 — Link Verification (Claude)
         ↓
Phase 5 — Internal Linking (verify / complete)
         ↓
Phase 6 — Publish to [YOUR_CMS_PLATFORM]  ← see Article Publishing SOP
         ↓
Phase 7 — Schema Generation & Insertion  ← see Schema Generation SOP
```

> **Note:** This SOP covers Phases 0–5 only. Phases 6 and 7 are covered by their own dedicated SOPs — see the Sub-SOP Index in the Master SOP.

---

## Project Knowledge Dependencies

Before starting any article, confirm these files are present in your Claude Project Knowledge. If any are missing, seek direction from management before proceeding.

| File | Purpose | What breaks without it |
|------|---------|------------------------|
| `[your-brand]-article-writer-SKILL-v2-1.md` | The article writer skill | Nothing runs |
| `[your-brand]-article-prompt-reusable-variables.md` | Pre-filled product facts, URLs, certifications | Product facts must be reconstructed manually; inconsistency and error risk |
| `[your-brand]-brand-voice-style-guide.md` | Tone, language rules, what to avoid | Claude defaults to generic health content voice |
| `article-link-checker-SKILL.md` | Link verification (Phase 4) | Link verification cannot run |
| Hub index for the product (e.g. `melatonin-content-hub-master-index.md`) | Internal linking reference (Phase 5) | Internal link verification cannot be completed |

> Skills must be in Project Knowledge to survive across sessions. A skill that only exists in the container during a single session is gone when the session ends.

---

## Phase 0 — Site Mapping (CLUSTER ARTICLES ONLY)

**When:** Before writing the first article in any new product cluster. Skip for standalone news blog articles.

**What it produces:** A complete URL architecture for all planned articles in the cluster — pillar, cluster articles, and phase articles — with SEO-optimized slugs, keywords, tags, and an internal linking plan for the full cluster.

**Tool:** Site Mapping SOP (uses the Dan Kurtz Site Mapping Prompt).

**Output required before proceeding:**
- [ ] Full article list with titles, keywords, URL slugs, and tags — saved to Project Knowledge as the hub index file
- [ ] Internal linking plan defined for the entire cluster
- [ ] Article to be written now identified by its URL slug and position in the cluster

**Decision gate:** If no site mapping has been done for this product cluster, stop and complete Phase 0 before proceeding. Writing articles without a defined URL architecture creates orphan content and internal linking gaps that are expensive to fix retroactively.

---

## Phase 1 — Keyword & Topic Definition

All inputs for cluster articles come from the [YOUR_PROJECT_MANAGEMENT_TOOL] task, which in turn reflects the site mapping output. All inputs for standalone articles come from the [YOUR_PROJECT_MANAGEMENT_TOOL] task, which reflects the PAA Extractor output. Do not invent or adjust keyword targets independently.

Confirm the following are all present before opening Claude:

| Field | Source |
|-------|--------|
| Primary keyword | [YOUR_PROJECT_MANAGEMENT_TOOL] task (cluster: from site mapping; standalone: exact PAA question) |
| Secondary keyword | [YOUR_PROJECT_MANAGEMENT_TOOL] task (optional) |
| Article topic | [YOUR_PROJECT_MANAGEMENT_TOOL] task |
| Target blog | [YOUR_PROJECT_MANAGEMENT_TOOL] task |
| Article type | [YOUR_PROJECT_MANAGEMENT_TOOL] task (Cluster — pillar / cluster / phase — or Standalone) |
| Associated product | [YOUR_PROJECT_MANAGEMENT_TOOL] task |
| Focus question | [YOUR_PROJECT_MANAGEMENT_TOOL] task (optional) |
| Strategic brief | [YOUR_PROJECT_MANAGEMENT_TOOL] task (optional — positioning notes, competitor gaps, content angles) |

**For cluster articles:** Confirm the hub index file for this product is present in Project Knowledge and contains the internal linking plan. This is the reference Claude will use in Phase 5. If it is missing, seek direction from management before starting.

If any required field is missing from the [YOUR_PROJECT_MANAGEMENT_TOOL] task, seek direction from management before starting. Do not proceed with assumptions.

---

## Phase 2 — Research

**Tool:** `[your-brand]-article-writer-SKILL-v2-1.md` (Section 1 — Phase 1 Research Prompt)

### How to run this phase

Do not copy and paste the prompt manually. Instead, invoke the skill directly in your Claude session:

> *"Please run the [YOUR_BRAND_NAME] article writer skill ([your-brand]-article-writer-SKILL-v2-1.md) for an article on [primary keyword]. The associated product is [product name]. Secondary keyword is [secondary keyword, if any]."*

Claude will read the skill from Project Knowledge and begin the research phase. It may ask you to confirm the product details or whether you are ready to proceed — respond with the relevant information from your Phase 1 inputs and `[your-brand]-article-prompt-reusable-variables.md`.

> **Claude may run Phases 2 and 3 together in a single pass.** The skill is designed to run research and then move directly into article generation in the same session without requiring you to do anything between phases. If this happens, proceed directly to the Phase 3 quality check below — you have not missed a step.

If you prefer to run the phases separately (e.g. to review sources before generation), tell Claude after the research phase output is returned: *"Please pause here — I want to review the sources before proceeding to article generation."*

### Quality check on research output

Before proceeding to Phase 3 (or before confirming Claude should proceed if it pauses to ask), verify the research output meets these standards:

- [ ] 9–12 external sources returned (plus 2 [YOUR_BRAND_NAME] brand sources)
- [ ] At least 5 sources are PubMed/NIH studies, systematic reviews, or peer-reviewed journal articles
- [ ] Every peer-reviewed source has journal name, volume/issue, and year recorded
- [ ] All URLs look like direct links to specific pages — not homepages, not search results
- [ ] Key stats are specific — percentages, participant counts, measurable outcomes
- [ ] No Wikipedia, low-authority blogs, or non-[YOUR_BRAND_NAME] supplement company pages

**Stat specificity — examples:**
- ❌ Reject: "melatonin helps with sleep" — not a stat
- ❌ Reject: "many people use melatonin" — not specific enough
- ✅ Accept: "across 19 trials and 1,683 participants, melatonin reduced sleep onset by 7.06 minutes vs. placebo"
- ✅ Accept: "melatonin supplement use increased 425% over two decades"

**Stat verification — most important check:** For each source, ask: if I opened this URL right now, would I find this specific stat on this page? One test article cited StatPearls for "30–60% first-pass metabolism" — StatPearls actually says 90%. The URL was correct, the source credible, but the stat was wrong. This class of error survives Phase 3 and the link checker unless caught here.

**If quality is insufficient:** Do not proceed to Phase 3 with weak sources. Ask Claude to find a stronger source for a specific entry, or manually substitute a better URL in the research output block before continuing.

---

## Phase 3 — Article Generation

**Tool:** `[your-brand]-article-writer-SKILL-v2-1.md` (Section 2 — Phase 2 Article Prompt)

If Claude ran Phases 2 and 3 together, the article may already be in your session. Proceed directly to the quality check below.

If Phase 2 ended with a research output block and Claude is waiting, tell it to proceed:

> *"The sources look good — please proceed to article generation."*

Claude will use the research output already in context along with the skill instructions and Project Knowledge files to generate the full HTML article.

### Quality check on article output

- [ ] Metadata block present above the HTML (SEO Title, Meta Description, Suggested URL, Tags, Image Prompt, Alt Text)
- [ ] `<h1>` is the first tag in the HTML body — not just in the metadata note
- [ ] Intro is 2–3 sentences and no more than 100 words
- [ ] Key Takeaways box present with inline CSS styling (5 bullets, 1 stat + 1 hyperlink each)
- [ ] Table of Contents present, positioned after Key Takeaways and before first H2
- [ ] Every TOC entry links to a matching `id` attribute on the correct H2
- [ ] 5–7 main content sections with H2 headings
- [ ] Dedicated [YOUR_BRAND_NAME] business section (~200–250 words)
- [ ] FAQ section (5–6 questions with 2–3 sentence answers)
- [ ] Conclusion with CTA linking to the product page
- [ ] Research References section (numbered list; peer-reviewed sources include journal name, volume, year)
- [ ] Author Bio (exact standard text)
- [ ] Full Medical Disclaimer and FDA/Health Canada Statement (exact standard text)
- [ ] Word count is under 3,500
- [ ] All hyperlinks use resolved URLs — no placeholder `source-1` style references remain
- [ ] Output is HTML — not Markdown

**If word count exceeds 3,500:** Ask Claude to trim the longest main content sections. Do not trim disclaimers, author bio, or Research References.

**If any checklist item fails:** Tell Claude specifically what is missing or wrong and ask it to fix it before proceeding.

---

## Phase 4 — Link Verification

**Tool:** `article-link-checker-SKILL.md`

**Trigger phrase:** *"Check the links in this article"*

**What it checks:**
- Every external URL in the article is live
- The cited stat or claim matches what the linked page actually says
- Anchor text accurately represents the destination
- [YOUR_BRAND_NAME] internal links match the product page URLs in Project Knowledge

**Do not skip this phase.** Broken or mismatched citations in a health article directly harm E-E-A-T credibility.

**Output:** Structured audit report with ✅ / ⚠️ / ❌ per link, and a READY TO PUBLISH or NEEDS FIXES verdict.

**If NEEDS FIXES:** Correct the flagged links in the HTML before proceeding. Do not publish with broken or mismatched citations.

---

## Phase 5 — Internal Linking

### For cluster articles

Internal links for cluster articles are defined at site mapping time and captured in the hub index file in Project Knowledge. Claude has access to this file and should have included internal links automatically during article generation.

**Your role in this phase is to verify, not to build:**

1. Scan the generated article HTML for internal links to other [YOUR_BRAND_NAME] articles and the associated product page
2. Confirm at least 3–6 internal links are present, including:
   - At minimum, 1 link to the most closely associated [YOUR_BRAND_NAME] product page
   - At minimum, 2 links to other published articles in the same cluster (where they exist)
3. If internal links are present and correct: proceed to Phase 6

**If internal links are missing or insufficient**, do not add them manually. Push back to Claude:

> *"The article is missing internal links. Please refer to [hub index filename] in Project Knowledge and add the appropriate internal links from the cluster linking plan."*

Claude will identify the relevant links from the site mapping output and insert them at appropriate points in the article.

> **Links to not-yet-published articles:** If a link target from the hub index does not yet exist as a published article, Claude should insert it as a placeholder comment using the format defined in the URL Placeholders SOP (`SOP-[your-brand]-url-placeholders.md`) — not as a live hyperlink, and not omitted. Confirm placeholders are present for all not-yet-published targets before proceeding to Phase 6.

**Anchor text rules (verify these regardless of how links were added):**
- Anchor text must be descriptive of the destination — not "click here" or "learn more"
- Internal links do NOT use `target="_blank"` (same-site navigation)
- Do not force links — only include where the reference is genuinely relevant

**Phase 5 verification checklist (cluster articles):**
- [ ] At minimum 1 link to the most closely associated [YOUR_BRAND_NAME] product page is present
- [ ] At minimum 2 links to other published articles in the same cluster are present (where they exist)
- [ ] Any internal links to not-yet-published articles are present as placeholder comments in the correct format (`PLACEHOLDER-LINK:`) — not hyperlinked, not omitted

### For standalone articles

Internal links for standalone articles are not pre-defined at site mapping. After article generation, scan the article for natural opportunities to link to:
- The most closely associated [YOUR_BRAND_NAME] product page (required)
- Any topically adjacent published articles across any [YOUR_BRAND_NAME] blog (minimum 2)

If the hub index for a relevant product is in Project Knowledge, ask Claude to suggest appropriate links from that index. Insert approved links into the HTML following the anchor text rules above.

---

## Phase 6 — Publish to [YOUR_CMS_PLATFORM]

See the **Article Publishing SOP** (`SOP-article-publishing-shopify.md` in Project Knowledge).

Complete that SOP in full before proceeding to Phase 7.

---

## Phase 7 — Schema Generation & Insertion

See the **Schema Generation SOP** (`SOP-schema-generation-shopify.md` in Project Knowledge).

Complete that SOP in full, then submit the article URL for indexing via the **Indexing SOP** (`SOP-indexing-google-search-console.md` in Project Knowledge).

---

## Article Elements Checklist (Final Pre-Publish Review)

Use this as a final gate before handing off to Phase 6. Every article must contain all of the following.

**Structure**
- [ ] Title: max 60 characters, includes primary keyword, includes a power word
- [ ] Intro: max 100 words, 1–2 stats, no more than 3 paragraphs
- [ ] Key Takeaways: 5 bullets, 1 stat + 1 hyperlink each, inline CSS div
- [ ] Table of Contents: linked, 8–12 entries, after Key Takeaways, before first H2
- [ ] Every TOC entry links to a matching `id` attribute on the correct H2
- [ ] 5–7 main content sections with H2 headings
- [ ] Dedicated [YOUR_BRAND_NAME] business section
- [ ] FAQ section: 5–6 questions with 2–3 sentence answers
- [ ] Conclusion: 2–3 sentences, CTA to product page

**Citations and References**
- [ ] 12–18 stats distributed across the article (not clustered in one section)
- [ ] 15–25 hyperlinks to external sources (resolved URLs, no placeholders)
- [ ] Research References section: numbered list, peer-reviewed sources include journal/volume/year
- [ ] All links verified live and accurately cited (Phase 4 complete)

**Internal Linking**
- [ ] At least 1 internal link to the most closely associated product page
- [ ] At least 2 internal links to other [YOUR_BRAND_NAME] articles (cluster) or adjacent articles (standalone)

**End Matter**
- [ ] Author Bio: exact standard text (David Kimbell)
- [ ] Medical Disclaimer: exact standard text
- [ ] FDA/Health Canada Statement: exact standard text

**Technical**
- [ ] HTML fragment (no `<html>`, `<head>`, or `<body>` wrappers)
- [ ] `<h1>` is first tag in HTML body
- [ ] All external hyperlinks use `target="_blank" rel="noopener noreferrer"`
- [ ] Internal links do NOT use `target="_blank"`
- [ ] imagePrompt comments present before each section
- [ ] Word count: under 3,500

---

## Quick Reference: Which Skills to Use

| Task | Skill / SOP |
|------|-------------|
| Research and article generation | `[your-brand]-article-writer-SKILL-v2-1.md` |
| Link verification | `article-link-checker-SKILL.md` |
| Schema generation | `[your-brand]-schema-generator-SKILL.md` + `SOP-schema-generation-shopify.md` |
| Publishing | `SOP-article-publishing-shopify.md` |
| Indexing | `SOP-indexing-google-search-console.md` |
| Site mapping (cluster only) | Site Mapping SOP (Dan Kurtz Site Mapping Prompt) |
| Standalone keywords | `SOP-install-and-run-PAA-extractor` |

---

## Common Mistakes — Do Not Repeat

1. **Skipping Phase 0 for a cluster article.** Writing cluster articles without a site mapping creates orphan content, duplicate slugs, and internal linking gaps that are expensive to fix retroactively.

2. **Accepting weak research sources.** If Claude returns Wikipedia, supplement brand blogs, or unsupported stats in Phase 2, push back before proceeding to Phase 3. The research phase is the cheapest point to fix citation quality.

3. **Fabricated journal metadata in Research References.** If Phase 2 didn't return journal/volume/year for a study, do not let Claude invent it in Phase 3. Flag it as `[journal details not confirmed]` and verify manually.

4. **Skipping the link checker.** External research URLs change. A stat cited from a PubMed study may be misquoted or the URL may have changed. The link checker catches this before it goes live.

5. **Manually building internal links for cluster articles instead of having Claude use the site mapping output.** The links are already defined — Claude should apply them. Manual link insertion risks inconsistency with the cluster plan.

6. **Using the abbreviated disclaimers from older articles.** The full Medical Disclaimer and FDA/Health Canada Statement are required. Short one-line versions are insufficient.

7. **Not matching the [YOUR_CMS_PLATFORM] page title to the `<h1>`.** They are separate fields in [YOUR_CMS_PLATFORM]. Set both explicitly at publish time from the article metadata block.

8. **The StatPearls melatonin stat.** StatPearls (NBK534823) states **90%** first-pass liver metabolism via CYP1A2 — not 30–60%. This exact error appeared in generated content. When any melatonin bioavailability article cites first-pass metabolism, verify the figure against the source before publishing.

9. **Skills not in Project Knowledge.** Skills must be uploaded to Project Knowledge to survive across sessions. A skill that only exists in the container during a session is gone when the session ends.
