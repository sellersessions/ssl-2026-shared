---
name: [your-brand]-schema-generator
description: Generate complete, optimized JSON-LD schema markup for [YOUR_BRAND_NAME] health articles published on [YOUR_CMS_PLATFORM] blogs. Use this skill when creating or updating schema for supplement articles (melatonin, K2, D3+K2, marine collagen, magnesium, vitamin C, serrapeptase, nattokinase) following the pillar-cluster-phase content architecture. Automatically determines required schema types based on article characteristics and generates production-ready JSON-LD for [YOUR_CMS_PLATFORM] Custom JSON-LD Schema metafields.
---

# [YOUR_BRAND_NAME] Schema Generator

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


Generate complete, validated JSON-LD schema markup for [YOUR_BRAND_NAME] health/supplement articles on [YOUR_CMS_PLATFORM].

## Core Principles

1. **Universal schema** applies to ALL articles (Article, BreadcrumbList, MedicalWebPage, Product, FAQPage, SpeakableSpecification)
2. **Conditional schema** added based on article type (HowTo, ItemList, Table, SearchAction)
3. **Product-agnostic templates** adapt to any [YOUR_BRAND_NAME] supplement
4. **[YOUR_CMS_PLATFORM]-optimized** using Liquid variables for dynamic dates
5. **Validation-ready** output passes Schema.org + Google Rich Results Test

## Article Classification System

### Content Architecture Types
- **Pillar**: Main hub article for a supplement topic
- **Cluster**: Core subtopic articles (dosage, timing, delivery methods, quality, special use cases)
- **Phase 1/2/3**: Supporting articles in content expansion phases

### Article Characteristics (determines conditional schema)
- **Procedural**: Contains step-by-step instructions → Add HowTo
- **Comparison**: Ranks/compares options → Add ItemList
- **Data-heavy**: Contains comparison tables → Add Table
- **Condition-specific**: Targets medical condition → Add healthCondition to MedicalWebPage
- **Age-specific**: Targets age group → Add suggestedMinAge to MedicalWebPage
- **Hub article**: Links to multiple related articles → Add ItemList of related content

## Universal Schema Components

These apply to EVERY article. See `references/schema-templates.md` for complete JSON templates.

**Required for ALL articles:**
1. Article - Core article metadata
2. BreadcrumbList - Navigation hierarchy
3. MedicalWebPage - Health content E-E-A-T signal
4. Product - [YOUR_BRAND_NAME] product featured
5. FAQPage - Question/answer content
6. SpeakableSpecification - Voice search optimization

## Conditional Schema Logic

### HowTo Schema
**When**: Step-by-step instructions (dosage protocols, timing guides, treatment protocols)
**Indicators**: "protocol", "guide", "how to use", numbered steps, sequential procedures

### ItemList Schema
**When**: Comparisons, rankings, or hub articles linking related content
**Indicators**: "comparison", "vs", "ranked", "best", pillar articles with cluster links

### Table Schema
**When**: Data comparison tables present
**Indicators**: Dosage ranges, bioavailability data, absorption rates

### SearchAction Schema
**When**: ONLY for pillar articles (main hub pages)

## Product Catalog

See `references/products.md` for all [YOUR_BRAND_NAME] product specifications including:
- Liposomal Melatonin
- K2
- D3+K2
- Marine Collagen
- Magnesium
- Vitamin C
- Serrapeptase
- Nattokinase

Each product entry includes: name, SKU, URL, image URL, description, additional properties, pricing, ratings.

## Medical Conditions Reference

Common healthCondition values:
- Insomnia, Delayed Sleep Phase Syndrome (DSPS), Shift Work Sleep Disorder
- Vitamin D Deficiency, Osteoporosis
- Cardiovascular Health, Joint Health, Immune System Support

## Decision Tree

```
START: Analyze article
│
├─ Pillar article? → Add SearchAction + ItemList
├─ Step-by-step instructions? → Add HowTo
├─ Compares/ranks options? → Add ItemList
├─ Data tables? → Add Table
├─ Condition-specific? → Add healthCondition
├─ Age-specific? → Add suggestedMinAge
│
END: Generate complete schema
```

## Output Format

Always generate complete, production-ready JSON-LD:
```json
{
  "@context": "https://schema.org",
  "@graph": [
    // All schema objects here
  ]
}
```

## ⚠️ Enumeration Validation — MANDATORY PRE-OUTPUT CHECKLIST

Schema.org enumeration values must be **exact**. Semantically plausible values that are not in the official enumeration will pass casual review but **fail Schema.org validation**. This has caused production errors in past [YOUR_BRAND_NAME] schema. Run this checklist on every schema before outputting.

---

### 1. MedicalSpecialty — STRICT (must use valid Schema.org URLs)

**Format:** `"specialty": "http://schema.org/[Value]"`

**✅ VALID values for [YOUR_BRAND_NAME] content:**

| Value | Use for |
|-------|---------|
| `http://schema.org/Neurologic` | Sleep, melatonin, circadian rhythm, insomnia, DSPS |
| `http://schema.org/Nutrition` | Vitamin C, vitamin D, collagen, magnesium, general supplements |
| `http://schema.org/Cardiovascular` | Nattokinase, K2, D3+K2 (cardiovascular angle) |
| `http://schema.org/Orthopedic` | Collagen, K2, joint health content |
| `http://schema.org/Immunology` | Vitamin C (immune focus), immune support content |
| `http://schema.org/Geriatric` | Seniors/older adults content |
| `http://schema.org/SportsMedia` | Athletic recovery, performance content |

**❌ INVALID values that look plausible but will FAIL validation:**

| Invalid value | Why it fails | Use instead |
|--------------|-------------|-------------|
| `http://schema.org/Pharmacy` | Not a valid MedicalSpecialty enum | `Neurologic` (sleep) or `Nutrition` |
| `http://schema.org/Supplement` | Does not exist | `Nutrition` |
| `http://schema.org/NutritionalMedicine` | Not a valid enum | `Nutrition` |
| `http://schema.org/SleepMedicine` | Does not exist | `Neurologic` |
| `http://schema.org/Immunology` | ✅ Valid — listed above | — |
| `http://schema.org/CardiovascularMedicine` | Not a valid enum | `Cardiovascular` |

> **Rule:** If in doubt, use `http://schema.org/Nutrition` for supplement content. It is always valid and broadly applicable.

---

### 2. audienceType — STANDARD

**Format:** `"audienceType": "Patient"`

- ✅ Always use `"Patient"` for consumer health content
- ❌ Never use descriptive strings like `"Adults with sleep difficulties"` — these are non-standard
- ❌ Never use `"Consumer"` or `"General Public"` — not standard MedicalAudience values

---

### 3. ItemAvailability — STRICT (must use full Schema.org URL)

**Format:** `"availability": "https://schema.org/InStock"`

- ✅ `"https://schema.org/InStock"` — standard for all in-stock [YOUR_BRAND_NAME] products
- ❌ `"InStock"` — short form fails validation (missing full URL)
- ❌ `"http://schema.org/InStock"` — use `https://` not `http://`

---

### 4. ItemListOrder — STRICT

- ✅ `"https://schema.org/ItemListOrderDescending"` — ranked lists (best to worst)
- ✅ `"https://schema.org/ItemListOrderAscending"` — ascending ranked lists
- ✅ `"https://schema.org/ItemListUnordered"` — hub article link lists
- ❌ `"Descending"` or `"descending"` — short forms fail validation

---

### 5. priceCurrency — STANDARD

- ✅ `"USD"` — for all US-priced products
- ✅ `"CAD"` — if Canadian pricing is ever used
- ❌ `"US Dollars"` or `"dollars"` — must be ISO 4217 currency codes

---

### 6. Liquid Variable for dateModified — REQUIRED

Every Article and MedicalWebPage must use:
```
"dateModified": "{{ article.updated_at | date: '%Y-%m-%d' }}"
"lastReviewed": "{{ article.updated_at | date: '%Y-%m-%d' }}"
```
Never hardcode a static date for these fields.

---

### Pre-Output Self-Check

Before finalising any schema output, verify:

- [ ] `specialty` value exists at schema.org/MedicalSpecialty — not just plausible-sounding
- [ ] `audienceType` is `"Patient"` — not a custom string
- [ ] `availability` uses full `https://schema.org/InStock` URL
- [ ] `ItemListOrder` uses full Schema.org URL
- [ ] `priceCurrency` is ISO 4217 code
- [ ] `dateModified` and `lastReviewed` use Liquid variables, not static dates
- [ ] No placeholder text (`[TO BE PROVIDED]`, `[Article Title]`, etc.) remains in output

---

## Validation Requirements

Schema must:
1. Pass Schema.org validator — Zero errors
2. Pass Google Rich Results Test — Only non-critical warnings
3. Use Liquid variables for dateModified: `{{ article.updated_at | date: '%Y-%m-%d' }}`
4. Include all universal components
5. Include appropriate conditional components

## Usage Workflow

1. **User provides**: title, URL, type, characteristics, audience, product, existing schema
2. **Analyze**: article type, required conditional schema, product details
3. **Generate**: universal + conditional components with product-specific details
4. **Output**: Complete JSON-LD + validation checklist

## Quality Checklist

- [ ] All URLs absolute and correct
- [ ] Product details match actual product
- [ ] dateModified uses Liquid variable
- [ ] FAQs are natural language questions
- [ ] HowTo steps are clear and sequential
- [ ] ItemList properly ranked (if applicable)
- [ ] BreadcrumbList positions sequential (1, 2, 3)
- [ ] MedicalWebPage has appropriate audience targeting
- [ ] No placeholder text remains

## Adaptation for New Products

When creating schema for new products:
1. Reference `references/products.md` for specifications
2. Adapt Product schema with correct details
3. Update MedicalWebPage specialty if needed
4. Maintain all universal schema components
5. Apply same conditional logic

## Notes

- **Token efficient**: Prioritizes concise, production-ready output
- **Consistent**: Follows patterns from 12 melatonin articles
- **Flexible**: Adapts to new products and article types
- **Validation-first**: Schema must pass validators
- **[YOUR_CMS_PLATFORM]-native**: Uses Liquid variables for dynamic content
