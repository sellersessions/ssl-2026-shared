# SOP: Generate and Implement JSON-LD Schema for a [YOUR_BRAND_NAME] Article

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


---

## Where This Fits in the Full Workflow

Schema generation is Phase 7 of the eight-phase [YOUR_BRAND_NAME] content workflow. The article must already be published before this SOP begins — do not start here until the Article Publishing SOP is complete.

| Phase | SOP | What it produces |
|---|---|---|
| 0 — Site Mapping *(cluster only)* | Site Mapping SOP (`SOP-[your-brand]-site-mapping.md`) | Full cluster architecture: article list, URLs, titles, keywords, tags, internal linking plan |
| 0b — URL Placeholders *(cluster only)* | URL Placeholders SOP (`SOP-[your-brand]-url-placeholders.md`) | Placeholder comments inserted for all not-yet-published link targets; [YOUR_PROJECT_MANAGEMENT_TOOL] tasks updated |
| 1–5 — Write | Article Writing SOP (`SOP-[your-brand]-article-writing-v1-1.md`) | Finished HTML article, link-verified and internally linked |
| 6 — Publish | Article Publishing SOP (`SOP-article-publishing-shopify.md`) | Live [YOUR_CMS_PLATFORM] blog post with all fields populated |
| **7 — Schema** | **This SOP** | JSON-LD schema inserted into the Custom JSON-LD Schema metafield and validated |
| 8 — Index | Indexing SOP (`SOP-indexing-google-search-console.md`) | Article submitted to [YOUR_SEARCH_CONSOLE] |

---

## Background: What Schema Is and Why It Matters

### What schema does

Every [YOUR_BRAND_NAME] article you publish is just text and HTML to a search engine — it has no inherent meaning. **Schema markup** (also called structured data) solves this by embedding a layer of machine-readable metadata directly into the page that tells Google, Bing, and AI engines exactly what the content is: what article this is, who wrote it, what product it discusses, what questions it answers, and more.

When search engines can read this metadata with confidence, two things happen:

1. **SEO benefit**: Google uses schema to generate rich results — FAQ dropdowns, breadcrumb trails, product ratings — that take up more space in search results and attract more clicks. Pages with accurate, validated schema consistently outperform equivalent pages without it.

2. **AEO benefit** (Answer Engine Optimization): AI-powered answer engines — including Google's AI Overviews, ChatGPT, Perplexity, and others — rely heavily on structured data when deciding which sources to cite and quote. A well-schemaed article is far more likely to be pulled into an AI-generated answer than one without it. This is increasingly where organic traffic is won or lost.

The quality of the schema matters as much as its presence. Generic, low-detail schema provides minimal signal. Accurate, detailed, article-specific schema is a meaningful competitive advantage.

### "Schema" is not one thing — it's a collection

When we say "generate the schema" for an article, we are not generating a single block of code. We are generating a **collection of schema objects** bundled together in one JSON-LD file. Each object describes a different aspect of the page. Think of it as filing several different forms with Google at once — each one adds a different layer of meaning.

The [YOUR_BRAND_NAME] Schema Generator produces two categories of schema for every article:

**Universal schema** — included in every article regardless of type:

| Schema Type | What it tells search engines |
|---|---|
| **Article** | Core metadata: title, author, publisher, publication date, and the page the article lives on |
| **BreadcrumbList** | The navigation path to this page (Home → Melatonin → This Article), which Google displays in search results |
| **MedicalWebPage** | Signals that this is health content, who the intended audience is, and what medical specialty it relates to — a key E-E-A-T signal for supplement content |
| **Product** | Details about the [YOUR_BRAND_NAME] product featured in the article: name, price, availability, ratings, and a direct link to buy |
| **FAQPage** | The questions and answers embedded in the article, formatted so Google can display them as expandable FAQ dropdowns directly in search results |
| **SpeakableSpecification** | Identifies which sections of the article are suitable for voice search and text-to-speech responses |

**Conditional schema** — added only when the article warrants it:

| Schema Type | When it's included | What it does |
|---|---|---|
| **HowTo** | Articles with step-by-step protocols or instructions | Enables Google to display the steps directly in search results as an interactive guide |
| **ItemList** | Comparison or ranking articles; also all pillar articles | Signals a ranked or ordered list of items, enabling list-style rich results; on pillar articles, lists all related hub content |
| **Table** | Articles containing data comparison tables | Tells search engines a structured data table is present and what it compares |
| **SearchAction** | Pillar articles only | Tells Google that the site has a search function and how to use it, enabling sitelinks search box in results |

All of these objects are generated together as a single JSON-LD file and inserted into one field in [YOUR_CMS_PLATFORM]. From the outside it looks like one thing; under the hood it is doing many different jobs simultaneously.

---

**Who this is for:** A VA who has already written a [YOUR_BRAND_NAME] article and is ready to generate and insert the custom JSON-LD schema markup into [YOUR_CMS_PLATFORM].

**Assumes the following are already complete:**
- Article has been written using the [YOUR_BRAND_NAME] article writer skill
- Article HTML/markdown has been pasted into [YOUR_CMS_PLATFORM] (title, body, metadata, SEO fields)
- The article URL slug is finalized in [YOUR_CMS_PLATFORM]
- Article type (Pillar / Cluster / Phase), product association, and target audience are known

---

## Required Project Knowledge Files

Before running this SOP, confirm the following three files are present in your Claude Project Knowledge. If any are missing, seek direction from management before proceeding — do not attempt to reconstruct them.

| File | Purpose |
|---|---|
| `[your-brand]-schema-generator-SKILL.md` | The schema generator skill — without this, schema generation cannot run |
| `[your-brand]-schema-generator-products.md` | Product data required by the schema generator |
| `[your-brand]-schema-generator-schema-templates.md` | Schema templates required by the schema generator |

---

## Step 1 — Work Inside the Correct Claude Project

This SOP must be completed inside the **[YOUR_BRAND_NAME] Claude Project** — not in a general Claude chat. The [YOUR_BRAND_NAME] Article Writer skill, the [YOUR_BRAND_NAME] Schema Generator skill, and all supporting product and article reference files have been added to that project's **Project Knowledge**, which makes them accessible to Claude automatically.

If you are not sure which project to use, seek direction from management.

> **Do not run this workflow in a general Claude chat.** The skills and reference files will not be available and the output will be unreliable.

---

## Step 2 — Confirm the Article Content is Available to Claude

The schema generator needs to read the full article to generate accurate schema. Before prompting Claude, identify which of the following scenarios applies to you:

**Scenario A — You just wrote the article in this same Claude session**
The article content is already in Claude's session memory. You do not need to paste or reference anything — just proceed to Step 3 and Claude will use the session context.

**Scenario B — The article was written in a previous session and the file is saved in Project Knowledge**
This is the most common case if the article was generated in an earlier Claude session. The file will typically be named something like `CORRECTED-melatonin-dosage-guide.md`. You do not need to paste the article — Claude can retrieve it by filename.

> **How to check for Scenario B:** Ask Claude: *"Do you have the article file for [article title] saved in this project?"* Claude will confirm or let you know it cannot find it.

**Scenario C — The article file is not in session memory or Project Knowledge**
If Claude cannot find the file and you are starting fresh, you will need to paste the full article HTML or markdown directly into the chat when you invoke the skill in Step 3.

---

## Quick Reference: Article Type Definitions

You will need to identify the article type in Step 3. Use this guide:

| Type | What it is | Example |
|---|---|---|
| **Pillar** | The main hub article for an entire supplement topic. Links out to all cluster and phase articles. One per supplement. | *Liposomal Melatonin: The Complete Guide* |
| **Cluster** | A core subtopic article that explores one key aspect of the supplement in depth. Directly linked from the pillar. | *Melatonin Dosage Guide*, *Best Time to Take Melatonin* |
| **Phase** | A supporting article that expands the hub. Covers more specific use cases, comparisons, or audience segments. | *Melatonin for Shift Workers*, *Melatonin vs. Prescription Sleep Aids* |

If you are still unsure which type applies, seek direction from management before proceeding.

---

## Step 3 — Invoke the Schema Generator Skill

Choose the prompt below that matches your scenario from Step 2.

### Scenario A — Article is already in session memory (you just wrote it):

```
Please use the [your-brand]-schema-generator skill to generate the complete JSON-LD schema for the article we just created. Use the article content, title, URL, type, and product details already in this session.
```

### Scenario B — Article file is saved in Project Knowledge:

```
Please use the [your-brand]-schema-generator skill to generate the complete JSON-LD schema for the following article:

- Article title: [PASTE TITLE]
- Article URL: [PASTE FULL URL, e.g. https://www.[YOUR_DOMAIN]/blogs/melatonin/melatonin-dosage-guide]
- Article type: [Pillar / Cluster / Phase — refer to definitions above]
- Associated product: [e.g. Liposomal Melatonin]
- The article file is saved in this project as: [PASTE FILENAME, e.g. CORRECTED-melatonin-dosage-guide.md]

Please retrieve the article, classify it, and generate the full production-ready schema.
```

### Scenario C — You need to paste the article content:

```
Please use the [your-brand]-schema-generator skill to generate the complete JSON-LD schema for the following article. The full article content is pasted below.

- Article title: [PASTE TITLE]
- Article URL: [PASTE FULL URL]
- Article type: [Pillar / Cluster / Phase — refer to definitions above]
- Associated product: [e.g. Liposomal Melatonin]

[PASTE FULL ARTICLE HTML OR MARKDOWN HERE]
```

---

## Step 4 — Review Claude's Output

Claude will return a complete JSON-LD schema block. Before proceeding, do a quick sanity check:

- [ ] The article title in the schema matches your [YOUR_CMS_PLATFORM] article title exactly
- [ ] The article URL in the schema matches the live [YOUR_CMS_PLATFORM] URL exactly
- [ ] The product name and URL match the correct [YOUR_BRAND_NAME] product page
- [ ] There are no placeholder values like `[INSERT HERE]` or `YOUR_VALUE` remaining
- [ ] The FAQ questions look like real questions a reader would ask (see example below)

**What a good FAQ entry looks like:**
```json
{
  "@type": "Question",
  "name": "How long does it take for melatonin to work?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "Liposomal melatonin typically begins to take effect within 20–30 minutes due to its enhanced absorption. Standard melatonin may take 45–60 minutes. Take it 30–60 minutes before your target bedtime."
  }
}
```

**What a bad FAQ entry looks like (do not accept this):**
```json
{
  "@type": "Question",
  "name": "What is melatonin?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "Melatonin is a hormone. It helps with sleep."
  }
}
```

A good FAQ answer is specific, useful, and directly answers the question with enough detail to stand alone. A bad FAQ answer is generic filler that adds no value. If you see answers like the bad example above, tell Claude to rewrite the FAQs with more specific, substantive answers before proceeding.

If anything else looks wrong, tell Claude specifically what to fix before moving on.

---

## Step 5 — Confirm the Article Is Live

Before testing the schema, confirm the article is published and accessible at its live URL. The Article Publishing SOP should have completed this — this step is a verification only.

1. Open the live article URL in your browser
2. Confirm the page loads correctly and the article body, title, and featured image all appear as expected
3. Copy the exact URL from your browser address bar — you will need it for the validator tests in Step 6

> **If the article is not yet published:** Stop and complete the Article Publishing SOP before proceeding. Schema must be validated against a live URL — testing raw code snippets produces unreliable results.

---

## Step 6 — Validate the Schema Against the Live URL

Run both of the following tests using the **live article URL**.

### Test 1 — Schema.org Validator
1. Go to: **https://validator.schema.org**
2. Click the **URL** tab, paste the live article URL, and run the test
3. Expected result: **Zero errors.** Warnings are acceptable; errors are not.

### Test 2 — Google Rich Results Test
1. Go to: **https://search.google.com/test/rich-results**
2. Paste the live article URL and run the test
3. Expected result: No critical errors. Non-critical warnings are acceptable.

> **Why test the live URL rather than pasting the raw JSON-LD code?** Pasting raw schema code into the validators can sometimes report errors that do not actually appear on the published page. The live URL gives you the ground truth. Always prefer the URL method.

---

## Step 7 — Fix Any Validation Errors

If either test returns errors:

1. Copy the full error message(s) from the validator
2. Return to Claude and paste the following:

```
The schema failed validation with the following error(s):

[PASTE ERROR MESSAGE(S) HERE]

Please fix the schema and return the corrected version.
```

3. Insert the corrected schema into the [YOUR_CMS_PLATFORM] metafield (see Step 8), save the article, then re-test the live URL in both validators
4. Repeat until both validators pass with zero errors

---

## Step 8 — Insert the Schema into [YOUR_CMS_PLATFORM]

Once both validators pass:

1. Return to the article in **[YOUR_CMS_ADMIN] → Content → Blog posts**
2. Scroll down to the **Metafields** section (below the main article editor)
3. Find the field labelled **Custom JSON-LD Schema**
4. Click into that field and paste the full JSON-LD output from Claude
5. Click **Save**

> **Cannot find the Custom JSON-LD Schema metafield?** Seek direction from management. Do not attempt to create or populate it yourself.

> **Do not paste the schema into the article body.** It belongs only in the metafield.

---

## Step 9 — Confirm and Mark Complete

1. Reload the live article URL in your browser and confirm the page still loads correctly
2. Optionally re-run a quick check in the Google Rich Results Test to confirm the schema is now detected on the live page
3. Update the task status in [YOUR_PROJECT_MANAGEMENT_TOOL] and add any notes if your workflow requires it

---

## Reference

| Resource | URL |
|---|---|
| Master SOP | `SOP-[your-brand]-master-1.md` in Project Knowledge |
| Schema.org Validator | https://validator.schema.org |
| Google Rich Results Test | https://search.google.com/test/rich-results |
| [YOUR_BRAND_NAME] Blog (Melatonin) | https://www.[YOUR_DOMAIN]/blogs/melatonin |
| [YOUR_BRAND_NAME] Blog (Vitamin C) | https://www.[YOUR_DOMAIN]/blogs/vitamin-c |
| Claude — [YOUR_BRAND_NAME] Project | https://claude.ai (open [YOUR_BRAND_NAME] project) |
| Questions / escalation | Seek direction from management |
