# SOP: Create and Manage Internal Link Placeholders Across a Content Cluster

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---

**Version 1.0 — March 2026**

---

## Where This Fits

This SOP runs once at cluster setup time, immediately after the Site Mapping SOP, before any articles are published. It also contains standing instructions that apply every time a new article in the cluster is published.

| Step | SOP | What it produces |
|------|-----|-----------------|
| 0 — Site Mapping | Site Mapping SOP (`SOP-[your-brand]-site-mapping.md`) | Full cluster architecture: article list, URLs, titles, keywords, tags, internal linking plan |
| **0b — Placeholders** | **This SOP** | Articles contain placeholder text for all future internal links, clearly marked for VA action when each target article is published |
| 1–5 — Write | Article Writing SOP (`SOP-[your-brand]-article-writing-v1.md`) | Finished HTML article |
| 6 — Publish | Article Publishing SOP (`SOP-article-publishing-shopify.md`) | Live [YOUR_CMS_PLATFORM] blog post |
| 7 — Schema | Schema Generation SOP (`SOP-schema-generation-shopify.md`) | JSON-LD schema inserted and validated |
| 8 — Index | Indexing SOP (`SOP-indexing-google-search-console.md`) | Article submitted to Google |

---

**Who this is for:** The person setting up a new product cluster (typically management or a senior VA), and any VA who publishes an article in an established cluster.

**Why this matters:** The internal linking plan is defined at site mapping time. Articles written early in the cluster — particularly the pillar and core cluster articles — are expected to link to articles that do not yet exist. Publishing broken hyperlinks pointing to non-existent URLs is harmful to SEO. This SOP defines how to handle those future links safely: as clearly marked, unlinked placeholder text that a VA can find and activate the moment each target article goes live.

---

## Part A — Setting Up Placeholders (Run Once at Cluster Setup)

### Step 1 — Understand the Placeholder Format

Wherever an article should eventually link to a not-yet-published article, the HTML contains:

1. **Visible anchor text** — readable by visitors, not hyperlinked
2. **An HTML comment immediately before it** — invisible on the published page, containing the future URL slug, anchor text, and target article title, formatted consistently so a VA can find it with Ctrl+F

**Standard placeholder format:**

```html
<!-- PLACEHOLDER-LINK: url="/blogs/[product-slug]/[article-slug]" anchor="[anchor text]" target="[Article Title]" -->
[anchor text]
```

**Example — pillar article linking to a future cluster article:**

```html
<!-- PLACEHOLDER-LINK: url="/blogs/melatonin/melatonin-dosage-guide" anchor="melatonin dosage guide" target="Melatonin Dosage Guide: How Much Should You Take?" -->
melatonin dosage guide
```

**When the target article is published**, the VA wraps the anchor text in a standard internal link tag and removes the comment:

```html
<a href="/blogs/melatonin/melatonin-dosage-guide">melatonin dosage guide</a>
```

**Key rules for placeholders:**
- The visible text must read naturally in the surrounding sentence — do not use "LINK TO COME" or similar as visible text
- Internal links do not use `target="_blank"` (same-site navigation)
- The comment format must be exact — `PLACEHOLDER-LINK:` is the search string a VA will use to find all outstanding placeholders in an article

---

### Step 2 — Identify Which Articles Need Placeholders Inserted

Using the Content Hub Master Index (saved to Project Knowledge in the Site Mapping SOP), identify every article in the cluster that links to one or more articles not yet published.

For a typical new cluster, this will include:
- **Pillar article** — links to all cluster and phase articles; most will be unpublished at launch
- **Cluster articles** — link to the pillar and to each other; some targets may be unpublished at launch
- **Phase articles** — link back to the pillar and relevant cluster articles; targets are usually published by the time phase articles are written, but not always

For each article, list which of its outbound internal links point to unpublished targets. This is your placeholder insertion list.

---

### Step 3 — Insert Placeholders Using Claude

This step is Claude-assisted. Open your [YOUR_BRAND_NAME] Claude Project and provide the following:

1. The article HTML (either already in session, or paste it in)
2. The list of internal links that need placeholder treatment (from Step 2)
3. The following instruction:

```
Please insert internal link placeholders into the article HTML wherever the following links are required but the target article is not yet published. Use this exact format for each placeholder:

<!-- PLACEHOLDER-LINK: url="[slug]" anchor="[anchor text]" target="[Article Title]" -->
[anchor text]

The anchor text must read naturally in the surrounding sentence. Do not hyperlink it — leave it as plain text with the comment immediately before it. Here are the links to placeholder:

[paste list of future links from the hub index, with URL slug, suggested anchor text, and target article title for each]
```

Review Claude's output to confirm:
- [ ] Every placeholder comment uses the exact `PLACEHOLDER-LINK:` format
- [ ] Anchor text reads naturally in context
- [ ] No placeholder text is hyperlinked
- [ ] No `<a href>` tags wrap placeholder text

---

### Step 4 — Update [YOUR_PROJECT_MANAGEMENT_TOOL] Tasks

For each article that contains placeholders, update its [YOUR_PROJECT_MANAGEMENT_TOOL] task to include a list of the placeholders it contains — specifically, which articles it is waiting on. Use this format in the task notes:

```
PLACEHOLDERS AWAITING ACTIVATION:
- /blogs/[product-slug]/[article-slug] — "[Article Title]" — activate when this article is published
- /blogs/[product-slug]/[article-slug] — "[Article Title]" — activate when this article is published
```

This makes the outstanding placeholder links visible in [YOUR_PROJECT_MANAGEMENT_TOOL] without requiring the VA to open [YOUR_CMS_PLATFORM] and search the HTML.

---

### Step 5 — Update Each Article's [YOUR_PROJECT_MANAGEMENT_TOOL] Task With Its "Activate in These Articles" List

For each not-yet-published article in the cluster, update its [YOUR_PROJECT_MANAGEMENT_TOOL] task to include which already-published articles contain a placeholder waiting for it. Use this format:

```
WHEN THIS ARTICLE IS PUBLISHED, ACTIVATE PLACEHOLDERS IN:
- [Article Title] — find PLACEHOLDER-LINK for /blogs/[product-slug]/[this-article-slug]
- [Article Title] — find PLACEHOLDER-LINK for /blogs/[product-slug]/[this-article-slug]
```

This is the trigger mechanism: when a VA publishes a new article, the [YOUR_PROJECT_MANAGEMENT_TOOL] task tells them exactly which other articles to update. They do not need to consult the hub index or figure this out themselves.

---

## Part B — Activating Placeholders When a New Article Is Published

These steps apply every time any article in the cluster is published. They are also referenced in the Article Publishing SOP.

### Step 6 — Check the [YOUR_PROJECT_MANAGEMENT_TOOL] Task for Placeholder Activation Instructions

When you publish a new article, open its [YOUR_PROJECT_MANAGEMENT_TOOL] task and look for the **"WHEN THIS ARTICLE IS PUBLISHED, ACTIVATE PLACEHOLDERS IN:"** section.

If this section is present, proceed to Step 7 for each article listed.

If this section is absent, it means either: (a) no earlier articles contain placeholders for this one, or (b) the task was not set up correctly in Step 5. If you suspect (b), check the Content Hub Master Index in Project Knowledge to confirm before skipping.

---

### Step 7 — Activate the Placeholders in Each Listed Article

For each article listed in the [YOUR_PROJECT_MANAGEMENT_TOOL] task:

1. Open the article in **[YOUR_CMS_ADMIN] → Content → Blog posts**
2. Switch to HTML view (`<>` button)
3. Use Ctrl+F to search for `PLACEHOLDER-LINK`
4. For each match, confirm it is the placeholder for the article you just published (check the `url=` value)
5. Replace the placeholder block with a standard internal link:

**Before:**
```html
<!-- PLACEHOLDER-LINK: url="/blogs/melatonin/melatonin-dosage-guide" anchor="melatonin dosage guide" target="Melatonin Dosage Guide: How Much Should You Take?" -->
melatonin dosage guide
```

**After:**
```html
<a href="/blogs/melatonin/melatonin-dosage-guide">melatonin dosage guide</a>
```

6. Save the article and reload the live page to confirm the link resolves correctly
7. Repeat for every article listed in the [YOUR_PROJECT_MANAGEMENT_TOOL] task

---

### Step 8 — Update [YOUR_PROJECT_MANAGEMENT_TOOL]

After activating placeholders in all listed articles:

1. In the newly published article's [YOUR_PROJECT_MANAGEMENT_TOOL] task, mark the placeholder activation items as complete
2. In each updated article's [YOUR_PROJECT_MANAGEMENT_TOOL] task, remove or mark complete the corresponding entry from its **"PLACEHOLDERS AWAITING ACTIVATION"** list

---

## Completion Gate (Part A — Cluster Setup)

Part A is complete when all of the following are true:

- [ ] Every article that links to a not-yet-published target has placeholder comments inserted in the correct format
- [ ] Every article's [YOUR_PROJECT_MANAGEMENT_TOOL] task lists the placeholders it contains (Step 4)
- [ ] Every not-yet-published article's [YOUR_PROJECT_MANAGEMENT_TOOL] task lists which articles will need updating when it is published (Step 5)
- [ ] No `<a href>` links in any published article point to a URL that returns a 404

---

## Quick Reference — Placeholder Format

**Insert (at cluster setup or article creation):**
```html
<!-- PLACEHOLDER-LINK: url="/blogs/[product-slug]/[article-slug]" anchor="[anchor text]" target="[Article Title]" -->
[anchor text]
```

**Activate (when target article is published):**
```html
<a href="/blogs/[product-slug]/[article-slug]">[anchor text]</a>
```

**Search string to find all placeholders in an article:** `PLACEHOLDER-LINK`

---

## Reference

| Resource | Location |
|----------|----------|
| Master SOP | `SOP-[your-brand]-master.md` in Project Knowledge |
| Site Mapping SOP | `SOP-[your-brand]-site-mapping.md` in Project Knowledge |
| Article Writing SOP | `SOP-[your-brand]-article-writing-v1.md` in Project Knowledge |
| Article Publishing SOP | `SOP-article-publishing-shopify.md` in Project Knowledge |
| Content Hub Master Index | Project Knowledge (product-specific, e.g. `melatonin-content-hub-master-index.md`) |
| [YOUR_BRAND_NAME] [YOUR_CMS_ADMIN] | https://admin.shopify.com |
