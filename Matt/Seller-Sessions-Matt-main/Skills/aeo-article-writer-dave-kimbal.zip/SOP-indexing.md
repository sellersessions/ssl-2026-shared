# SOP: Submit a Published [YOUR_BRAND_NAME] Article for Google Indexing

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


---

## Where This Fits in the Full Workflow

Indexing is Phase 8 — the final phase — of the eight-phase [YOUR_BRAND_NAME] content workflow. Do not run this SOP until the article is fully published with schema inserted and validated.

| Phase | SOP | What it produces |
|---|---|---|
| 0 — Site Mapping *(cluster only)* | Site Mapping SOP (`SOP-[your-brand]-site-mapping.md`) | Full cluster architecture: article list, URLs, titles, keywords, tags, internal linking plan |
| 0b — URL Placeholders *(cluster only)* | URL Placeholders SOP (`SOP-[your-brand]-url-placeholders.md`) | Placeholder comments inserted for all not-yet-published link targets; [YOUR_PROJECT_MANAGEMENT_TOOL] tasks updated |
| 1–5 — Write | Article Writing SOP (`SOP-[your-brand]-article-writing-v1-1.md`) | Finished HTML article, link-verified and internally linked |
| 6 — Publish | Article Publishing SOP (`SOP-article-publishing-shopify.md`) | Live [YOUR_CMS_PLATFORM] blog post with all fields populated |
| 7 — Schema | Schema Generation SOP (`SOP-schema-generation-shopify.md`) | JSON-LD schema inserted into the Custom JSON-LD Schema metafield and validated |
| **8 — Index** | **This SOP** | Article submitted to [YOUR_SEARCH_CONSOLE] for rapid indexing |

---

**Who this is for:** A VA who has completed Steps 1–3 and has a fully published, schema-validated article live on the [YOUR_BRAND_NAME] website.

**Assumes the following are already complete:**
- The article is published and accessible at its live URL
- The JSON-LD schema has been inserted into the Custom JSON-LD Schema metafield and the article has been republished
- Both the Schema.org Validator and Google Rich Results Test have passed

---

## Why You Need to Do This

Google's crawlers will eventually discover and index every new page on the [YOUR_BRAND_NAME] website on their own — but "eventually" can mean anywhere from a few days to several weeks for a newer site. Submitting the URL manually via [YOUR_SEARCH_CONSOLE] signals to Google that a new page exists right now and should be crawled promptly. For a content hub strategy where articles link to each other and build authority over time, getting each article indexed quickly matters. Do not skip this step.

---

## Step 1 — Confirm You Have [YOUR_SEARCH_CONSOLE] Access

[YOUR_SEARCH_CONSOLE] ([YOUR_SEARCH_CONSOLE]) access is required to complete this SOP. Before proceeding, confirm whether you have login access to the [YOUR_BRAND_NAME] [YOUR_SEARCH_CONSOLE] account.

**If you have [YOUR_SEARCH_CONSOLE] access:** Proceed to Step 2.

**If you do not have [YOUR_SEARCH_CONSOLE] access:**
1. Note the live article URL
2. Seek direction from management, providing the article URL and requesting that Steps 2–5 be completed
3. Mark the [YOUR_PROJECT_MANAGEMENT_TOOL] task as blocked pending [YOUR_SEARCH_CONSOLE] access and note what is needed

---

## Step 2 — Open [YOUR_SEARCH_CONSOLE]

1. Go to **https://search.google.com/search-console**
2. Log in with the account that has access to the [YOUR_BRAND_NAME] property
3. In the top-left dropdown, confirm the active property is **[YOUR_DOMAIN]**
4. If a different property is shown, click the dropdown and select the correct one

---

## Step 3 — Open the URL Inspection Tool

1. In the left-hand sidebar, click **URL inspection**
2. The search bar at the top of the page will show: *"Inspect any URL in '[YOUR_DOMAIN]'"*
3. Paste the full live article URL into that search bar (e.g. `https://www.[YOUR_DOMAIN]/blogs/melatonin/melatonin-dosage-guide`)
4. Press **Enter**

Google will run a check and return one of two results — see Step 4.

---

## Step 4 — Read the Inspection Result

### Result A — "URL is not on Google" *(most likely for a new article)*

This means Google has not yet indexed the page. This is normal and expected for a newly published article. You will see:

- A grey or blue information icon with the message **"URL is not on Google"**
- Below that, a status panel showing **"Page is not indexed: URL is unknown to Google"**
- In the top-right corner of the status panel: a **REQUEST INDEXING** button

Proceed to Step 5 to submit the indexing request.

### Result B — "URL is on Google"

This means Google has already discovered and indexed the page. This can happen quickly if the article was internally linked from an already-indexed page, or if the sitemap was recently crawled.

- You will see a green tick and the message **"URL is on Google"**
- No further action is required
- Note this in [YOUR_PROJECT_MANAGEMENT_TOOL] and mark the task complete (skip to Step 7)

### Result C — "URL is on Google, but has issues"

This means the page is indexed but Google has flagged a problem. Do not ignore this.

- Note the specific issue described on screen
- Take a screenshot
- Seek direction from management, providing the screenshot, before marking the task complete

---

## Step 5 — Request Indexing

1. In the status panel, click **REQUEST INDEXING** (top-right corner of the panel — refer to the screenshot in this SOP's project file if needed)
2. A spinner will appear while Google tests the live URL — this typically takes 10–30 seconds
3. When complete, a confirmation message will appear: **"Indexing requested"** (or similar wording)
4. Click **Done** or **Got it** to dismiss the confirmation

> **If the REQUEST INDEXING button is greyed out or unavailable:** This sometimes happens when Google has recently received a request for the same URL, or when the daily quota has been reached. Google allows approximately **15 indexing requests per day** across the entire property — if multiple articles have been submitted in quick succession, the quota may be exhausted. Wait 24 hours and try again. If it remains unavailable after 24 hours, seek direction from management.

---

## Step 6 — Verify the Request Was Received

After dismissing the confirmation:

1. Paste the same article URL into the URL inspection bar again and run a second check
2. You should now see a message indicating that the indexing request has been received — the status may still show "not indexed" at this stage, which is normal
3. The **Discovery** section at the bottom of the results panel should now show activity (rather than "No referring sitemaps detected" and "None detected" for the referring page)

Indexing itself does not happen instantly — see Step 7 for what to expect next.

---

## Step 7 — What to Expect After Submitting

| Timeframe | What typically happens |
|---|---|
| **0–24 hours** | Request received; Google queues the URL for crawling |
| **1–3 days** | Google crawls and indexes the page for most established sites |
| **Up to 2 weeks** | Outer limit for newer sites or pages with few inbound links |

**To check if the article has been indexed:**
1. Return to [YOUR_SEARCH_CONSOLE] → URL Inspection
2. Paste the article URL and run the check
3. If the status has changed to **"URL is on Google"**, indexing is complete

Alternatively, do a quick Google search for `site:[YOUR_DOMAIN]/blogs/[your-slug]` — if the page appears in results, it is indexed.

If the article is still not indexed after 2 weeks, seek direction from management and provide the article URL.

---

## Step 8 — Mark Complete

Update the [YOUR_PROJECT_MANAGEMENT_TOOL] task:
- Note the date the indexing request was submitted
- Note the current indexing status (e.g. "Indexing requested — not yet confirmed indexed")
- If you were unable to access [YOUR_SEARCH_CONSOLE] and escalated to management, note that as well
- Set a reminder to check indexing status in 3–5 days if your workflow requires confirmation

---

## Reference

| Resource | URL / Location |
|---|---|
| Master SOP | `SOP-[your-brand]-master-1.md` in Project Knowledge |
| [YOUR_SEARCH_CONSOLE] | https://search.google.com/search-console |
| Article Publishing SOP | Project Knowledge |
| Schema Generation SOP | Project Knowledge |
| Questions / escalation | Seek direction from management |
