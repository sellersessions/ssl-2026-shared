# [YOUR_BRAND_NAME] Content Operations — Master SOP

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---

**Version 1.1 — March 2026**
For use across all three [YOUR_BRAND_NAME] blogs.

---

## What This Document Is

This is the entry point for all [YOUR_BRAND_NAME] content work. It gives you the complete picture of how new articles are created, published, and indexed — and tells you exactly which sub-SOP to follow at each step.

**Do not skip this document.** Even if you have worked on [YOUR_BRAND_NAME] articles before, re-read this at the start of each content batch to confirm the workflow and file dependencies are current.

---

## Who This Is For

A VA or team member who will be writing, publishing, or managing [YOUR_BRAND_NAME] articles under a content plan assigned via [YOUR_PROJECT_MANAGEMENT_TOOL]. This SOP assumes:

- Basic familiarity with Claude (you know how to open a project and prompt Claude)
- Basic familiarity with [YOUR_CMS_PLATFORM] (you can navigate to Blog posts and edit fields)
- Access to a [YOUR_BRAND_NAME] Claude Project and [YOUR_CMS_ADMIN]

If either access is missing, seek direction from management before starting.

---

## The Three [YOUR_BRAND_NAME] Blogs

[YOUR_BRAND_NAME] currently operates three [YOUR_CMS_PLATFORM] blogs. Each serves a distinct purpose and has its own URL namespace.

| Blog | Purpose | URL Pattern |
|------|---------|-------------|
| Melatonin | Cluster articles around the melatonin supplement hub | `/blogs/melatonin/` |
| Vitamin C | Cluster articles around the Vitamin C supplement hub | `/blogs/vitamin-c/` |
| News | Standalone health and wellness articles not tied to a specific product cluster | `/blogs/news/` |

Additional product blogs will be added as content hubs expand. When a new blog is added, its URL pattern will be added to this table.

---

## Article Types

Every article is one of two types. Knowing the type determines how the article's keyword and topic are sourced, and whether Phase 0 (Site Mapping) is required.

### Cluster Article
An article that belongs to a structured content hub around a specific [YOUR_BRAND_NAME] product (e.g. melatonin, vitamin C). Cluster articles are planned as a group before any individual article is written. Each cluster has a pillar article, core cluster articles, and supporting phase articles.

**Keywords, article titles, URL slugs, and tags for cluster articles are all defined in the Site Mapping SOP output**, which is saved to Project Knowledge before any individual articles are written. When you receive a cluster article task in [YOUR_PROJECT_MANAGEMENT_TOOL], the keyword and title should already be in the task — sourced from the site mapping output, not invented independently.

**Requires Phase 0 — Site Mapping** before the first article in any new cluster is written.

### Standalone Article
An article published in the news blog that is not part of a product cluster. No site mapping is required.

**Keywords for standalone articles may come from the PAA (People Also Ask) Extractor.** The PAA SOP (`SOP-install-and-run-PAA-extractor` in Project Knowledge) explains how to run the extractor against a Google search query and obtain a CSV of question-based keywords. The primary keyword for each standalone article is the exact PAA question, used verbatim in the SEO title. The [YOUR_PROJECT_MANAGEMENT_TOOL] task will contain this keyword — if it is missing, seek direction from management before starting.

---

## The Complete Workflow

Every article goes through the same sequence of steps, in order. Do not skip steps or change the order.

```
[Cluster articles only]
Phase 0 — Site Mapping
        ↓
Phase 1 — Keyword & Topic Definition
        ↓
Phase 2 — Research  (Claude)
        ↓
Phase 3 — Article Generation  (Claude)
        ↓
Phase 4 — Link Verification  (Claude)
        ↓
Phase 5 — Internal Linking
        ↓
Phase 6 — Publish to [YOUR_CMS_PLATFORM]
        ↓
Phase 7 — Schema Generation & Insertion  (Claude)
        ↓
Phase 8 — [YOUR_SEARCH_CONSOLE] Indexing
```

> **Phase 6 (Publish) before Phase 7 (Schema) is correct and intentional — do not reverse this order.**
>
> The workflow is: publish the article first, then generate the schema, insert it into the Custom JSON-LD Schema metafield, and re-publish. The article therefore goes live twice: once as the initial publication (without schema), and once after schema has been inserted.
>
> While it is technically possible to generate and validate schema before an article is published — by pasting raw JSON-LD into a validator — this method produces false errors that do not reflect how the schema will actually behave on the live page. Testing against a real URL gives a clean, reliable result. This is why we always publish first.

---

## Sub-SOP Index

Each phase is covered in full by its own SOP. Use this table to navigate.

| Phase | Sub-SOP | Filename in Project Knowledge |
|-------|---------|-------------------------------|
| 0 — Site Mapping | Site Mapping SOP | `SOP-[your-brand]-site-mapping.md` |
| 0b — URL Placeholders | URL Placeholders SOP | `SOP-[your-brand]-url-placeholders.md` |
| 1–5 — Write | Article Writing SOP | `SOP-[your-brand]-article-writing-v1.md` |
| 6 — Publish | Article Publishing SOP | `SOP-article-publishing-shopify.md` |
| 7 — Schema | Schema Generation SOP | `SOP-schema-generation-shopify.md` |
| 8 — Index | Indexing SOP | `SOP-indexing-google-search-console.md` |
| Standalone keywords | PAA Extractor SOP | `SOP-install-and-run-PAA-extractor` |

**The Article Writing SOP (Phases 1–5) is the longest and most complex.** Read it fully before starting any new article. It contains decision gates, quality checks, and common mistakes to avoid that apply to all subsequent steps.

---

## Claude Project Setup

All Claude-assisted steps (Phases 2, 3, 4, and 7) must be run inside a [YOUR_BRAND_NAME] Claude Project — not in a general Claude chat.

**There is no single required project.** Because multiple people may be working on [YOUR_BRAND_NAME] content simultaneously, each operator may use their own Claude Project. As content hubs grow, it may also make sense to use separate projects for different product clusters to keep context focused. What matters is that the required Project Knowledge files are present in whichever project you are working in.

If you are starting work in a new project, or are unsure whether your project has the correct files, check the list below before starting any article work. If any file is missing, seek direction from management — do not proceed without them, and do not attempt to reconstruct missing files from memory.

### Required files in Project Knowledge

| File | Required by | What breaks without it |
|------|------------|------------------------|
| `[your-brand]-article-writer-SKILL-v2.md` | Phases 2–3 | Article research and generation cannot run |
| `[your-brand]-article-prompt-reusable-variables.md` | Phases 2–3 | Product facts must be reconstructed manually; introduces inconsistency and error risk |
| `[your-brand]-brand-voice-style-guide.md` | Phase 3 | Claude defaults to generic health content voice |
| `article-link-checker-SKILL.md` | Phase 4 | Link verification cannot run |
| `[your-brand]-schema-generator-SKILL.md` | Phase 7 | Schema generation cannot run |
| `[your-brand]-schema-generator-products.md` | Phase 7 | Schema generator has no product data |
| `[your-brand]-schema-generator-schema-templates.md` | Phase 7 | Schema generator has no templates |
| Hub index for the relevant product (e.g. `melatonin-content-hub-master-index.md`) | Phase 5 | Internal linking cannot be completed accurately |
| `SOP-[your-brand]-site-mapping.md` | Phase 0 (cluster articles) | VA cannot execute cluster setup without site mapping instructions |
| `SOP-[your-brand]-url-placeholders.md` | Phase 0b (cluster articles) | VA cannot correctly insert or activate placeholder links |

> **Note on skills and session memory:** Claude cannot remember anything between sessions unless it is in Project Knowledge. A skill file that only exists in the container during a session is gone when the session ends. All skills must be in Project Knowledge.

---

## Content Planning Inputs (Before Phase 1)

All content planning inputs come from your [YOUR_PROJECT_MANAGEMENT_TOOL] task. Do not proceed with any article until all required inputs are present in the task. If anything is missing or unclear, seek direction from management.

| Input | Notes |
|-------|-------|
| Primary keyword | Use exactly as written — do not paraphrase |
| Secondary keyword | Optional; use if present in the task |
| Article topic | One sentence describing what the article covers |
| Target blog | Matches the blog URL pattern |
| Article type | Cluster (with position: pillar / cluster / phase) or Standalone |
| Associated product | The [YOUR_BRAND_NAME] product most closely associated with this article |
| URL slug | Cluster articles: from site mapping output. Standalone articles: derived from the PAA question. |
| Internal linking targets | Cluster articles: listed in the hub index file in Project Knowledge |

---

## [YOUR_PROJECT_MANAGEMENT_TOOL] Task Management

Each article has its own [YOUR_PROJECT_MANAGEMENT_TOOL] task. Use it to track progress and hand off between phases.

### Status updates required at each phase completion

| Completed phase | Note to add in [YOUR_PROJECT_MANAGEMENT_TOOL] |
|-----------------|------------------------|
| Phase 1 | Keywords confirmed: [primary], [secondary if used] |
| Phase 3 | Article generated — [note filename or session] |
| Phase 4 | Link check: [READY TO PUBLISH / NEEDS FIXES — summarise any fixes made] |
| Phase 5 | Internal links added: [count and targets] |
| Phase 6 | Published. Live URL: [full URL] |
| Phase 7 | Schema inserted. Validators: passed |
| Phase 8 | Indexing requested: [date]. Status: [not yet indexed / confirmed indexed] |

If you are blocked at any point — missing inputs, unexpected errors, unclear instructions — note the issue in the [YOUR_PROJECT_MANAGEMENT_TOOL] task and seek direction from management before proceeding.

---

## Article Elements — Quick Reference

Every published article must contain all of the following. This is a summary only — full specifications and checklists are in the Article Writing SOP and Article Publishing SOP.

| Element | Spec |
|---------|------|
| Title | Max 60 characters, includes primary keyword and a power word |
| Intro | Max 100 words, 1–2 stats, 1–3 paragraphs |
| Key Takeaways box | 5 bullets with inline CSS styling, 1 stat + 1 hyperlink each |
| Table of Contents | Linked, 8–12 entries, after Key Takeaways, before first H2 |
| Main content sections | 5–7 H2 sections |
| Internal links | Min. 1 to associated product page; min. 2 to related published articles |
| Citations | 15–25 hyperlinks to external sources; 12–18 stats distributed throughout |
| Dedicated [YOUR_BRAND_NAME] section | ~200–250 words |
| FAQ section | 5–6 questions with 2–3 sentence answers |
| Conclusion | 2–3 sentences with CTA to product page |
| Research References | Numbered list; peer-reviewed sources include journal name, volume, and year |
| Author Bio | Standard David Kimbell text (in skill file) |
| Medical Disclaimer | Full standard text (in skill file) |
| FDA/Health Canada Statement | Full standard text (in skill file) |
| Output format | HTML fragment only — no `<html>`, `<head>`, or `<body>` wrappers |

---

## Common Mistakes — Do Not Repeat

These are the highest-cost mistakes in the [YOUR_BRAND_NAME] content workflow. Each has caused real problems in production.

1. **Skipping Phase 0 for a cluster article.** Writing cluster articles without a completed site mapping creates orphan content, duplicate slugs, and internal linking gaps that are expensive to fix retroactively.

2. **Using a general Claude chat instead of a [YOUR_BRAND_NAME] Claude Project with the correct Project Knowledge files.** The skills and reference files will not be available and output will be inconsistent.

3. **Starting Phase 3 (Article Generation) without reviewing Phase 2 (Research) output.** Weak or fabricated sources that pass through Phase 2 unchecked will appear in the published article. The research phase is the cheapest point to fix citation quality.

4. **Publishing before running the link checker (Phase 4).** External research URLs change. A stat cited from a PubMed study may be misquoted, or the URL may have moved. The link checker catches this before the article goes live.

5. **Reversing Phases 6 and 7.** The article must be published first, schema generated and validated against the live URL, then inserted and the article re-published. Do not attempt to insert schema into an unpublished article.

6. **Not matching the [YOUR_CMS_PLATFORM] page title to the `<h1>`.** These are separate fields in [YOUR_CMS_PLATFORM]. Set both explicitly at publish time from the article metadata block.

7. **Accepting fabricated journal metadata in Research References.** If Phase 2 did not return journal name, volume, and year for a peer-reviewed study, Claude must not invent it. Flag with `[journal details not confirmed]` and verify manually before publishing.

8. **Skipping internal linking.** Internal links are not optional. Every article must link to the associated product page and to at least 2 related published articles. This is a core part of the topical authority and AEO strategy.

---

## Reference — All SOPs and Resources

| Resource | Location |
|----------|----------|
| Site Mapping SOP | `SOP-[your-brand]-site-mapping.md` in Project Knowledge |
| URL Placeholders SOP | `SOP-[your-brand]-url-placeholders.md` in Project Knowledge |
| Article Writing SOP | `SOP-[your-brand]-article-writing-v1.md` in Project Knowledge |
| Article Publishing SOP | `SOP-article-publishing-shopify.md` in Project Knowledge |
| Schema Generation SOP | `SOP-schema-generation-shopify.md` in Project Knowledge |
| Indexing SOP | `SOP-indexing-google-search-console.md` in Project Knowledge |
| PAA Extractor SOP | `SOP-install-and-run-PAA-extractor` in Project Knowledge |
| Skills Registry | `claude-skills-registry.md` in Project Knowledge |
| [YOUR_BRAND_NAME] [YOUR_CMS_ADMIN] | https://admin.shopify.com |
| [YOUR_SEARCH_CONSOLE] | https://search.google.com/search-console |
| Schema.org Validator | https://validator.schema.org |
| Google Rich Results Test | https://search.google.com/test/rich-results |
| Image compression | https://squoosh.app or https://tinypng.com |

---

*This SOP is the parent document. All sub-SOPs listed above operate under it. When any sub-SOP is updated, check whether this master document also needs updating — particularly the workflow order, the sub-SOP index table, and the Project Knowledge file checklist.*
