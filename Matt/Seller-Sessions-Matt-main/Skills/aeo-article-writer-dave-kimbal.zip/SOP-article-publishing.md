# SOP: Publish a [YOUR_BRAND_NAME] Article in [YOUR_CMS_PLATFORM]

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


---

## Where This Fits in the Full Workflow

Publishing is Phase 6 of the eight-phase [YOUR_BRAND_NAME] content workflow. Each phase depends on the previous one being complete. Do not skip ahead.

| Phase | SOP | What it produces |
|---|---|---|
| 0 — Site Mapping *(cluster only)* | Site Mapping SOP (`SOP-[your-brand]-site-mapping.md`) | Full cluster architecture: article list, URLs, titles, keywords, tags, internal linking plan |
| 0b — URL Placeholders *(cluster only)* | URL Placeholders SOP (`SOP-[your-brand]-url-placeholders.md`) | Placeholder comments inserted for all not-yet-published link targets; [YOUR_PROJECT_MANAGEMENT_TOOL] tasks updated |
| 1–5 — Write | Article Writing SOP (`SOP-[your-brand]-article-writing-v1-1.md`) | Finished HTML article, link-verified and internally linked |
| **6 — Publish** | **This SOP** | A live [YOUR_CMS_PLATFORM] blog post with all fields populated, ready for schema generation |
| 7 — Schema | Schema Generation SOP (`SOP-schema-generation-shopify.md`) | JSON-LD schema inserted into the Custom JSON-LD Schema metafield and validated |
| 8 — Index | Indexing SOP (`SOP-indexing-google-search-console.md`) | Article submitted to [YOUR_SEARCH_CONSOLE] |

> **Important:** Schema cannot be generated as part of this SOP. The Custom JSON-LD Schema metafield will be left empty when you first publish. You will return to add the schema after completing the Schema Generation SOP. The article will be published and live without schema in the interim — this is expected and intentional.

---

**Who this is for:** A VA who has completed the Article Writing SOP and has a finished article file ready to publish in [YOUR_CMS_PLATFORM].

**Assumes the following are already complete:**
- The Article Writing SOP has been completed in full
- The finished article file (HTML) is available — either in the current Claude session, in Project Knowledge, or saved locally
- The article title, URL slug, meta description, tags, MidJourney prompt, and featured image alt text were all produced during the article writing stage

---

## Step 1 — Confirm You Have Everything Before You Start

Before opening [YOUR_CMS_PLATFORM], confirm the following are all present in your article writing output. If any item is missing, do not proceed — seek direction from management before starting.

- [ ] Article title (exact, final version)
- [ ] Full article body in **HTML format** (see note below)
- [ ] Meta title
- [ ] Meta description (140–160 characters)
- [ ] URL slug (e.g. `melatonin-dosage-guide`)
- [ ] Tags (5–8 tags — see note below)
- [ ] MidJourney prompt for the featured image
- [ ] Alt text for the featured image

**HTML vs. Markdown:** Articles should be delivered as HTML and pasted into [YOUR_CMS_PLATFORM]'s HTML editor. This is the standard and preferred format. If your article output is in Markdown format, it must be converted to HTML before pasting — do not paste Markdown directly into the [YOUR_CMS_PLATFORM] visual editor, as [YOUR_CMS_PLATFORM] does not handle it reliably and formatting will break. If you are unsure how to convert Markdown to HTML, seek direction from management before proceeding.

**A note on tags:** Tags for each article are defined in the tagging strategy document in Project Knowledge (`melatonin-tagging-strategy-complete.md` for melatonin articles; equivalent documents exist for other products). If the tags are not in your article writing output, check the tagging strategy document. Tags must never be invented from scratch — they must follow the established structure. If you cannot find the correct tags after checking both sources, publish the article anyway but seek direction from management before marking the task complete.

---

## Step 2 — Generate and Prepare the Featured Image

The featured image must be ready before you publish.

### 2a — Generate the image in MidJourney

1. Open MidJourney (via Discord or the MidJourney web app)
2. Locate the MidJourney prompt from your article writing output
3. Paste the prompt and generate the image
4. Review the results and select the variation that best represents the article topic in a clean, professional, supplement-brand-appropriate style
5. Download the selected image as a **PNG file**

### 2b — Resize the image to 300KB or smaller

The image must be **300KB maximum** before uploading to [YOUR_CMS_PLATFORM].

- **On a Mac:** Open the PNG in the built-in Preview app. Go to **Tools → Adjust Size** to reduce dimensions, or **File → Export** to reduce quality/file size. No additional software needed.
- **On Windows or any device:** Use **Squoosh** (squoosh.app) or **TinyPNG** (tinypng.com) — both are free and browser-based.

Aim for 300KB or below. Lower is fine as long as the image looks sharp at full width. There is no required naming convention for the file.

---

## Step 3 — Create a New Blog Post in [YOUR_CMS_PLATFORM]

1. Log into **[YOUR_CMS_ADMIN]**
2. Navigate to **Content → Blog posts**
3. Click **Add blog post** (top right corner)

---

## Step 4 — Paste the Article HTML and Extract the Publishing Details

This is the most important step to do carefully. The article HTML you paste will contain not just the article body, but also a block at the very top with the publishing metadata you need for other fields (meta title, meta description, URL slug, MidJourney prompt, and alt text). You will use those details to populate the relevant [YOUR_CMS_PLATFORM] fields, then **remove them from the content area** before publishing.

### 4a — Paste the HTML

1. In the content area, click the **`<>`** (HTML editor) button in the top-right corner of the editor to switch to HTML view
2. Paste the full article HTML from your article writing output

### 4b — Read the metadata block at the top

Switch back to the visual editor (`<>` button again) and scroll to the very top of the content area. You will see a block of plain visible text sitting above the article body — it is not part of the article and will appear on the published page if you do not remove it. This block contains the publishing details you need for the other [YOUR_CMS_PLATFORM] fields:

- **Meta title** — copy this; you will paste it into the SEO fields in Step 5
- **Meta description** — copy this; you will paste it into the SEO fields in Step 5
- **URL slug** — copy this; you will paste it into the SEO fields in Step 5
- **MidJourney prompt** — you should have already used this in Step 2; confirm it matches
- **Alt text for the featured image** — copy this; you will use it in Step 7

Copy each item and keep them somewhere accessible (a notepad, sticky note, or second browser tab) before moving on.

### 4c — Verify the article body

While in the visual editor, scroll through the rest of the article and confirm:
- Headings, bold text, lists, and any tables render correctly
- The Key Takeaways box appears correctly formatted
- The Table of Contents appears below the introduction

### 4d — Delete the metadata block

Select all the visible metadata text at the top of the content area — everything above the article title or first heading — and delete it. You can do this in the visual editor directly, or switch to the HTML editor (`<>`) and delete the corresponding lines there.

When you are done, the top of the content area in the visual editor should show:
1. The article title *(or first H1 heading)*
2. The introductory paragraphs
3. The Key Takeaways box
4. The Table of Contents
5. The remaining article content

Nothing else should appear above the introduction. Take a moment to confirm this before continuing — if the metadata text is still visible here, it will appear on the published page.

---

## Step 5 — Populate the SEO Fields

Scroll down to the **Search engine listing** section and click **Edit** if it is collapsed.

### Meta title (Page title)
- Paste the meta title you copied in Step 4b
- Should be 50–60 characters; **do not exceed 60 characters** — anything longer gets truncated in Google search results, which undermines SEO

### Meta description
- Paste the meta description you copied in Step 4b
- Should be 140–160 characters; **do not exceed 160 characters** — longer descriptions get cut off in search results
- The [YOUR_CMS_PLATFORM] preview will show the character count; use it to verify

### URL slug (URL and handle)
- [YOUR_CMS_PLATFORM] auto-generates a slug from the article title — **replace it** with the exact slug you copied in Step 4b
- Must be lowercase and hyphen-separated, with no spaces or special characters
- Example: `melatonin-dosage-guide`
- **Do not modify or invent a slug.** The slug must match what was defined during article structure setup.

> **Why this matters:** The URL slug is effectively permanent once the article is indexed. Changing it later requires a redirect and risks breaking inbound links. Get it right before publishing.

---

## Step 6 — Populate the Organisation Fields

These fields are in the **right-hand sidebar**.

### Visibility
- Confirm the **Visibility** box is set to **Visible**
- This is the setting that makes the article publicly accessible when published

### Blog
- Select the correct blog from the dropdown
- Currently there are three blogs: **Melatonin**, **Vitamin C**, and **News** — more may be added as the content hub expands
- Match the blog to the article's subject matter and URL slug (e.g. an article with `/blogs/melatonin/` in its URL belongs in the Melatonin blog)
- If you are unsure which blog to select, check the URL slug or seek direction from management

### Author
- Set the author to **Dave Kimbell**
- This applies regardless of who is doing the publishing

### Theme template
- Set the theme template to **Default blog post**
- If this field shows something different, change it before publishing

### Tags
- Add each tag from your article writing output or the tagging strategy document
- Enter tags as comma-separated values or one at a time
- Use 5–8 tags following the conventions in the tagging strategy document exactly
- Example: `melatonin-guide, use-case-guides, shift-work, sleep-disorders, dosage-protocols, timing-protocols, occupational-health, circadian-rhythm`

---

## Step 7 — Add the Excerpt

Scroll to the **Excerpt** field (below the main content area).

1. Paste the **meta title** into the excerpt field
2. Select the pasted text and apply **bold formatting**

The excerpt is displayed on blog index pages. Using the bolded meta title here is the standard [YOUR_BRAND_NAME] practise.

---

## Step 8 — Upload the Featured Image

1. In the right-hand sidebar, find the **Featured image** section
2. Click **Upload image** (or drag and drop)
3. Select the compressed PNG file you prepared in Step 2
4. Once uploaded, click the image and add the **alt text** you copied in Step 4b
5. Do not leave alt text blank

---

## Step 9 — Leave the JSON-LD Schema Field Empty

1. Scroll down to the **Metafields** section
2. Locate the **Custom JSON-LD Schema** field
3. **Leave it empty**

Schema generation is handled by the Schema Generation SOP. The article goes live without schema and is republished with schema added after that SOP is complete. This is normal and expected.

> **Why publish before generating schema?** Schema validation must be run against a live URL. Generating schema before publishing and pasting raw JSON-LD into a validator produces false errors that do not reflect how the schema will behave on the live page. Publishing first, then generating and validating schema against the real URL, gives a clean and reliable result. The article will be live without schema briefly — this is intentional.

> If you cannot find the Custom JSON-LD Schema metafield, seek direction from management. Do not attempt to create or populate it yourself.

---

## Step 10 — Final Pre-Publish Checklist

- [ ] Article title is correct
- [ ] Article body renders correctly in the visual editor — no broken formatting, missing sections, or stray code
- [ ] Metadata block has been **removed** from the top of the content area
- [ ] Meta title is populated in SEO fields
- [ ] Meta description is populated in SEO fields
- [ ] URL slug matches the one from the article writing output
- [ ] Visibility is set to **Visible**
- [ ] Blog is correctly selected
- [ ] Author is set to **Dave Kimbell**
- [ ] Theme template is set to **Default blog post**
- [ ] Tags are entered (5–8 tags, following tagging strategy)
- [ ] Excerpt field contains the bolded meta title
- [ ] Featured image is uploaded with alt text
- [ ] Custom JSON-LD Schema metafield is **empty**

---

## Step 11 — Publish

1. Click **Save** (or **Save and Publish**) in the top right
2. Open the live article URL in your browser and confirm the page loads correctly
3. Confirm the featured image, title, and article body all appear as expected
4. Confirm the metadata block does **not** appear anywhere on the published page

---

## Step 11b — Activate Placeholder Links

Check the [YOUR_PROJECT_MANAGEMENT_TOOL] task for this article for a **"WHEN THIS ARTICLE IS PUBLISHED, ACTIVATE PLACEHOLDERS IN:"** section.

- **If this section is present:** Follow Part B of the URL Placeholders SOP (`SOP-[your-brand]-url-placeholders.md`) to activate the placeholder links in each listed article before proceeding to Step 12.
- **If this section is absent:** Either no earlier articles contain placeholders for this one, or the task was not set up correctly during cluster setup. If you suspect the latter, check the Content Hub Master Index in Project Knowledge to confirm before skipping.

Do not proceed to Step 12 until placeholder activation is complete or confirmed not required.

---

## Step 12 — Hand Off to Schema Generation

1. Copy the exact live article URL from your browser address bar
2. Open the **Schema Generation SOP** in Project Knowledge and follow it from Step 1, using this URL
3. When schema generation and validation are complete, you will return to this article in [YOUR_CMS_PLATFORM], paste the schema into the Custom JSON-LD Schema metafield, and republish

---

## Step 13 — Mark Complete

Update the task in [YOUR_PROJECT_MANAGEMENT_TOOL]. Note:
- The live article URL
- Whether tags were applied or flagged to management as missing
- That schema generation is the next required step

---

## Reference

| Resource | Location / URL |
|---|---|
| Article Writing SOP | Project Knowledge |
| Schema Generation SOP | Project Knowledge |
| Tagging Strategy (Melatonin) | `melatonin-tagging-strategy-complete.md` in Project Knowledge |
| Image compression — Mac | Preview app (built-in): Tools → Adjust Size or File → Export |
| Image compression — any device | https://squoosh.app or https://tinypng.com |
| [YOUR_BRAND_NAME] [YOUR_CMS_ADMIN] | https://admin.shopify.com |
| Questions / escalation | Seek direction from management |
