# [YOUR_BRAND_NAME] Products Catalog

> ⚠️ **THIS FILE REQUIRES FULL REPLACEMENT**  
> This file is a brand-specific product catalog from the original creator's supplement store.  
> Replace the entire contents below with your own product catalog, following the same  
> structure and format as a guide. Do not use this file as-is.
---


---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


Complete product specifications for schema generation.

## Liposomal Melatonin

**Product Details:**
- **Name**: Liposomal Liquid Melatonin
- **SKU**: MELATONIN001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-liquid-melatonin
- **Image URL**: https://cdn.shopify.com/s/files/1/0364/0528/0900/products/1_[YOUR_BRAND_NAME]LiposomalSublingualMelatonin100ml.jpg?v=1632337902
- **Description**: Premium Liposomal Liquid Melatonin designed for enhanced absorption to support restful sleep.
- **Category**: Health & Beauty > Vitamins & Supplements > Sleep Aids
- **Price**: $29.99
- **Rating**: 5 stars (2 reviews)

**Additional Properties:**
- Active Ingredient: Melatonin
- Delivery Method: Liposomal Liquid
- Volume: 100ml
- Bioavailability: 80-95%
- Absorption Time: 15-30 minutes

**Specialty**: Sleep Medicine

---

## Vitamin K2 (MK-7)

**Product Details:**
- **Name**: Liposomal Vitamin K2 (MK-7)
- **SKU**: K2MK7001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-vitamin-k2-mk7
- **Image URL**: [TO BE PROVIDED]
- **Description**: Premium Liposomal Vitamin K2 (MK-7) for bone and cardiovascular health.
- **Category**: Health & Beauty > Vitamins & Supplements > Vitamin K
- **Price**: [TO BE PROVIDED]
- **Rating**: [TO BE PROVIDED]

**Additional Properties:**
- Active Ingredient: Vitamin K2 (MK-7)
- Delivery Method: Liposomal Liquid
- Form: Menaquinone-7
- Bioavailability: [TO BE PROVIDED]

**Specialty**: Orthopedic Medicine / Cardiovascular Medicine

---

## Vitamin D3 + K2

**Product Details:**
- **Name**: Liposomal Vitamin D3 + K2 Complex
- **SKU**: D3K2001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-vitamin-d3-k2
- **Image URL**: [TO BE PROVIDED]
- **Description**: Synergistic combination of Vitamin D3 and K2 for optimal calcium metabolism and bone health.
- **Category**: Health & Beauty > Vitamins & Supplements > Vitamin Combinations
- **Price**: [TO BE PROVIDED]
- **Rating**: [TO BE PROVIDED]

**Additional Properties:**
- Active Ingredients: Vitamin D3 (Cholecalciferol), Vitamin K2 (MK-7)
- Delivery Method: Liposomal Liquid
- D3 Content: [TO BE PROVIDED]
- K2 Content: [TO BE PROVIDED]
- Bioavailability: [TO BE PROVIDED]

**Specialty**: Orthopedic Medicine / Nutritional Medicine

---

## Marine Collagen

**Product Details:**
- **Name**: Liposomal Marine Collagen
- **SKU**: COLLAGEN001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-marine-collagen
- **Image URL**: [TO BE PROVIDED]
- **Description**: Premium marine-sourced collagen peptides for skin, joint, and tissue health.
- **Category**: Health & Beauty > Vitamins & Supplements > Collagen
- **Price**: [TO BE PROVIDED]
- **Rating**: [TO BE PROVIDED]

**Additional Properties:**
- Active Ingredient: Marine Collagen Peptides
- Delivery Method: Liposomal Liquid
- Source: Wild-caught fish
- Type: Type I Collagen
- Bioavailability: [TO BE PROVIDED]

**Specialty**: Dermatology / Orthopedic Medicine

---

## Magnesium

**Product Details:**
- **Name**: Liposomal Magnesium Complex
- **SKU**: MAGNESIUM001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-magnesium
- **Image URL**: [TO BE PROVIDED]
- **Description**: Highly absorbable liposomal magnesium for muscle function, relaxation, and sleep support.
- **Category**: Health & Beauty > Vitamins & Supplements > Minerals
- **Price**: [TO BE PROVIDED]
- **Rating**: [TO BE PROVIDED]

**Additional Properties:**
- Active Ingredient: Magnesium
- Delivery Method: Liposomal Liquid
- Form: [Magnesium Glycinate/Citrate/etc - TO BE PROVIDED]
- Elemental Magnesium: [TO BE PROVIDED]
- Bioavailability: [TO BE PROVIDED]

**Specialty**: Sports Medicine / Sleep Medicine / Nutritional Medicine

---

## Vitamin C

**Product Details:**
- **Name**: Liposomal Vitamin C
- **SKU**: VITAMINC001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-vitamin-c
- **Image URL**: [TO BE PROVIDED]
- **Description**: Premium liposomal vitamin C for superior immune support and antioxidant protection.
- **Category**: Health & Beauty > Vitamins & Supplements > Vitamin C
- **Price**: [TO BE PROVIDED]
- **Rating**: [TO BE PROVIDED]

**Additional Properties:**
- Active Ingredient: Vitamin C (Ascorbic Acid)
- Delivery Method: Liposomal Liquid
- Dosage per serving: [TO BE PROVIDED]
- Bioavailability: [TO BE PROVIDED]

**Specialty**: Immunology / Nutritional Medicine

---

## Serrapeptase

**Product Details:**
- **Name**: Liposomal Serrapeptase
- **SKU**: SERRAPEPTASE001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-serrapeptase
- **Image URL**: [TO BE PROVIDED]
- **Description**: Proteolytic enzyme for inflammation support and tissue health.
- **Category**: Health & Beauty > Vitamins & Supplements > Enzymes
- **Price**: [TO BE PROVIDED]
- **Rating**: [TO BE PROVIDED]

**Additional Properties:**
- Active Ingredient: Serrapeptase
- Delivery Method: Liposomal Liquid
- Activity: [SPU or IU - TO BE PROVIDED]
- Bioavailability: [TO BE PROVIDED]

**Specialty**: Sports Medicine / Pain Management

---

## Nattokinase

**Product Details:**
- **Name**: Liposomal Nattokinase
- **SKU**: NATTOKINASE001
- **URL**: https://www.[YOUR_DOMAIN]/products/liposomal-nattokinase
- **Image URL**: [TO BE PROVIDED]
- **Description**: Fibrinolytic enzyme from fermented soybeans for cardiovascular health support.
- **Category**: Health & Beauty > Vitamins & Supplements > Enzymes
- **Price**: [TO BE PROVIDED]
- **Rating**: [TO BE PROVIDED]

**Additional Properties:**
- Active Ingredient: Nattokinase
- Delivery Method: Liposomal Liquid
- Activity: [FU - TO BE PROVIDED]
- Bioavailability: [TO BE PROVIDED]

**Specialty**: Cardiovascular Medicine

---

## Usage Notes

### Updating Product Information
When product details become available:
1. Replace [TO BE PROVIDED] with actual values
2. Add image URLs from [YOUR_CMS_PLATFORM] CDN
3. Update pricing and ratings
4. Verify SKU accuracy
5. Confirm product URLs

### Product Schema Guidelines
- Always use `@type: "Brand"` (not "Organization")
- Include priceValidUntil: "2026-12-31" (update annually)
- Add shippingDetails with US as addressCountry
- Include aggregateRating only if 2+ reviews exist
- List all relevant additionalProperty values
- Match specialty to primary health domain

### Category Selection
Common subcategories:
- Sleep Aids (melatonin, magnesium)
- Vitamin D / Vitamin K / Vitamin C (specific vitamins)
- Vitamin Combinations (D3+K2)
- Collagen (marine collagen)
- Minerals (magnesium)
- Enzymes (serrapeptase, nattokinase)
