---
name: article-qa-checker
description: Full pre-publish QA audit for [YOUR_BRAND_NAME] articles — covering structural integrity, citation number consistency, dual-link pair integrity, required elements, and complete hyperlink verification. Supersedes article-link-checker-SKILL.md. Use after every article is generated and before publishing to [YOUR_CMS_PLATFORM]. Triggers include: "run the QA checker", "check the article", "run the article QA", "verify links", "check the links", "are all the links working", "run the link checker".
---

# Article QA Checker

---
> **Developed and shared by:** Dave Kimbell  
> **Contact:** dave@davekimbell.com  
> **Website:** https://davekimbell.com/first-answer/  
---


Performs a complete pre-publish quality audit on a [YOUR_BRAND_NAME] article. Runs two phases in sequence:

- **Phase 1 — Structural Integrity Check**: Catches structural and citation problems that cannot be verified by link testing alone.
- **Phase 2 — Hyperlink Audit**: Verifies every URL is live, points to the correct source, and is accompanied by accurate anchor text.

Run this skill after every article is generated, before publishing. It is the final QA gate before an article goes live.

> **This skill supersedes `article-link-checker-SKILL.md`.** That file should be removed from Project Knowledge. Do not run both — run this one.

---

## When to Use

After article generation is complete and before handing off to the Article Publishing SOP (Phase 6). Takes approximately 5–8 minutes per article.

---

## Inputs Required

Either:
- The article HTML file (if available in the session), or
- The live published URL (if the article has already been published and you are running a post-publish audit)

If the article was generated in the same session, Claude already has it in context — no file path is needed.

---

## Phase 1 — Structural Integrity Check

Work through each check in order. Record every finding — do not resolve findings silently. All findings are reported in the Phase 1 section of the output report.

---

### Check 1.1 — Duplicate H1 Detection

**Why this matters:** [YOUR_CMS_PLATFORM] automatically generates an H1 from the article title field. If the article body also contains an `<h1>` tag, the rendered page will have two H1s — a direct SEO negative that Google penalises by treating the page topic as ambiguous.

**What to check:**
Count every `<h1>` tag in the article HTML body.

- ✅ **PASS** — Zero `<h1>` tags found in the article body. ([YOUR_CMS_PLATFORM] will supply the only H1 from the title field.)
- ❌ **FAIL** — One or more `<h1>` tags found in the article body.

**If FAIL:** The `<h1>` tag(s) in the body must be removed before publishing. The content beneath each `<h1>` should remain — only the tag itself changes, typically to nothing (the intro paragraph needs no heading at all) or to `<h2>` if it is a section heading that was incorrectly promoted.

> **Note:** This check requires reading the raw HTML. If only a rendered preview is available, the duplicate H1 may be invisible. Always check the raw HTML or the live rendered page source.

---

### Check 1.2 — Citation Number Consistency

**Why this matters:** Each numbered citation in the article body (e.g. `[8]`) is a reference to a specific entry in the Research References list at the bottom of the article. If a number in the body points to a different source than the same number in the References list, the article is misattributing claims — an E-E-A-T and credibility failure.

**What to check:**

Step 1: Extract the Research References list from the bottom of the article. Record each entry as: `[N] — Source description / title`.

Step 2: Scan the full article body for every citation number in the format `[N]`. For each, record: the number, the sentence it appears in, and the URL attached to it (if it is a hyperlink).

Step 3: Cross-reference. For every `[N]` in the body, confirm that the source it is attached to matches the entry for `[N]` in the References list.

**Status indicators:**
- ✅ **CONSISTENT** — All `[N]` citations in the body match the corresponding entry in the References list.
- ❌ **MISMATCH** — One or more `[N]` citations in the body refer to a different source than the References list entry for that number.

**If MISMATCH:** List every inconsistent citation with: the number, what the body says it refers to, and what the References list says it refers to. These must be reconciled before publishing — either the in-body number must be corrected, or the References list entry must be updated, consistently throughout the article.

---

### Check 1.3 — Dual-Link Pair Integrity

**Why this matters:** [YOUR_BRAND_NAME] articles use a dual-hyperlink citation format where both the anchor text and the `[N]` footnote marker are separately hyperlinked. In a correctly formed dual-link pair, both links go to the same source. If they go to different sources, the article is simultaneously citing two different papers for the same claim — a citation integrity failure that is invisible to readers but detectable by fact-checkers and AI answer engines.

**What to check:**

Identify every instance where a sentence contains both:
- An anchor text hyperlink (descriptive clickable text → URL), and
- A `[N]` citation number hyperlink immediately following it (footnote marker → URL)

For each dual-link pair, confirm both URLs resolve to the same source.

**Status indicators:**
- ✅ **CONSISTENT** — Both URLs in the pair point to the same source.
- ❌ **MISMATCH** — The anchor URL and the `[N]` URL point to different sources.
- ⚠️ **GHOST CITATION** — The anchor URL points to a source that does not appear anywhere in the Research References list. (This means a citation was embedded in the text but never added to the References list — a hidden source.)

**If MISMATCH or GHOST:** List the affected sentence, both URLs, and what each resolves to. The author must decide which source is the intended citation and reconcile both links and the References list entry accordingly.

---

### Check 1.4 — Table of Contents Completeness

**Why this matters:** Every H2 section in the article body should have a corresponding entry in the Table of Contents. Missing entries create navigation gaps and signal incomplete editing.

**What to check:**

Step 1: Extract every `<h2>` heading from the article body. Record the heading text and its `id` attribute (the anchor used for TOC linking).

Step 2: Extract every entry from the Table of Contents. Record the link text and the `href` anchor it links to.

Step 3: Cross-reference. Every H2 heading should have a matching TOC entry. Every TOC entry should link to an existing H2 `id`.

**Status indicators:**
- ✅ **COMPLETE** — Every H2 has a TOC entry; every TOC entry links to an existing H2.
- ⚠️ **PARTIAL** — The Conclusion and/or FAQ section is absent from the TOC. Flag but do not treat as a blocking issue — these are commonly omitted by convention.
- ❌ **INCOMPLETE** — One or more main content H2 sections are missing from the TOC, or one or more TOC entries link to an `id` that does not exist in the article body.

---

### Check 1.5 — Required Elements Presence

**Why this matters:** Every [YOUR_BRAND_NAME] article must contain all required structural elements for E-E-A-T compliance and brand consistency. Missing elements in a published article are difficult to retrofit cleanly.

**Check for the presence of each of the following:**

| Element | What to look for | Pass condition |
|---------|-----------------|----------------|
| Author bio | "David Kimbell" bio block at bottom | Present and matches standard text |
| Medical Disclaimer | Full disclaimer block | Present — not abbreviated |
| FDA/Health Canada Statement | Full regulatory statement | Present — not abbreviated |
| Publish date | Date in article metadata or byline | Present |
| Last Updated date | Updated date field | Present |
| Product internal link | Link to `[YOUR_DOMAIN]/products/` | At least one present |
| Key Takeaways box | Structured box with 5 bullets near top | Present |
| Research References section | Numbered list at bottom | Present with minimum 9 entries |

**Status indicators:**
- ✅ **PRESENT** — Element found and correctly formed.
- ❌ **MISSING or MALFORMED** — Element absent or abbreviated. Must be corrected before publishing.

---

### Check 1.6 — Unsupported Numerical Claims

**Why this matters:** Specific numerical claims (percentages, multipliers, counts) that appear without a citation are the most exposed claims in a health article from a regulatory and E-E-A-T standpoint. They read as marketing assertions rather than evidence.

**What to check:**
Scan the article body — particularly the [YOUR_BRAND_NAME] product section — for any sentence containing a specific number, percentage, ratio, or comparative figure that is not followed by a citation hyperlink or `[N]` reference.

**Status indicators:**
- ✅ **ALL SUPPORTED** — Every specific numerical claim has a citation.
- ⚠️ **UNSUPPORTED CLAIM** — One or more specific numerical claims have no citation. Flag the sentence and the specific figure. The author must either add a citation or rephrase to remove the unsupported specificity.

> **Common location for this issue:** The [YOUR_BRAND_NAME] Liposomal Melatonin product section, where bioavailability comparisons (e.g. "95% bioavailability vs 15% for standard tablets") appear as product claims. These require either a cited source or softer language ("significantly higher bioavailability" with no specific percentage).

---

## Phase 2 — Hyperlink Audit

### Step 2.1: Extract All Links

Read the article HTML and extract every `<a href="...">` tag. For each link record:
- The full URL
- The anchor text (visible clickable text)
- The number of times this URL appears in the article (instance count)

Deduplicate by URL — each unique URL is checked once regardless of how many times it appears.

Print a pre-check summary:
```
HYPERLINK AUDIT: [article title or filename]
Total link instances: [N]
Unique URLs to verify: [N]
```

Then list every unique URL with its instance count and anchor text(s):
```
 1. [3x]  https://pubmed.ncbi.nlm.nih.gov/23691095/
          Anchor text(s): "a 2013 meta-analysis", "clinical research"
 2. [1x]  https://www.sleepfoundation.org/melatonin/melatonin-side-effects
          Anchor text: "Sleep Foundation"
```

---

### Step 2.2: Verify Each URL

For each unique URL, run a `web_search` using the URL itself as the search query.

Evaluate against three criteria:

**A. Liveness**
- ✅ LIVE — the exact URL appears in search results
- ⚠️ NOT INDEXED — URL not found in search results (may be live but not indexed; flag for manual check)
- ❌ DEAD — search returns no results and the domain appears unreachable

**B. Source accuracy**
Cross-reference the page title and snippet returned against what the article claims from that source. Flag if the page title or content does not match the citation context.

Examples of mismatches to flag:
- Article cites a melatonin dosage statistic, but the linked page is about jet lag
- Article cites a 2024 meta-analysis, but the page title shows a 2012 study
- Article attributes a claim to Mayo Clinic, but the URL resolves to a Sleep Foundation page

**C. Anchor text accuracy**
Assess whether the anchor text accurately represents the destination. Flag if:
- The anchor text implies a specific finding the linked page does not contain
- The anchor text is misleading about the source (e.g. "Harvard research confirms X" but the page only discusses X tangentially)

---

### Step 2.3: Internal Links

List all links to `[YOUR_DOMAIN]/blogs/` separately. Cross-reference against the confirmed published URL list in Project Knowledge. Internal blog links may be too new to be indexed — flag as ⚠️ for manual click-check rather than treating as dead.

Verify:
- At least 1 internal link to the most closely associated [YOUR_BRAND_NAME] product page
- At least 2 internal links to other published [YOUR_BRAND_NAME] articles

---

## Output Report

After completing both phases, output a single structured report in this format:

```
═══════════════════════════════════════════════════════
ARTICLE QA REPORT: [article title]
Date: [today's date]
═══════════════════════════════════════════════════════

PHASE 1 — STRUCTURAL INTEGRITY
───────────────────────────────────────────────────────

1.1 Duplicate H1
[✅ PASS / ❌ FAIL — details]

1.2 Citation Number Consistency
[✅ CONSISTENT / ❌ MISMATCH — list any mismatches]

1.3 Dual-Link Pair Integrity
[✅ CONSISTENT / ❌ MISMATCH / ⚠️ GHOST CITATION — details]

1.4 Table of Contents Completeness
[✅ COMPLETE / ⚠️ PARTIAL / ❌ INCOMPLETE — details]

1.5 Required Elements
[✅ ALL PRESENT / ❌ MISSING: list missing elements]

1.6 Unsupported Numerical Claims
[✅ ALL SUPPORTED / ⚠️ UNSUPPORTED: list flagged sentences]

───────────────────────────────────────────────────────
PHASE 2 — HYPERLINK AUDIT
───────────────────────────────────────────────────────

SUMMARY
Total unique URLs checked: [N]
✅ Confirmed live & accurate: [N]
⚠️ Needs manual check: [N]
❌ Broken or inaccurate: [N]

RESULTS

✅ https://pubmed.ncbi.nlm.nih.gov/31722088/
   Title: Adverse Events Associated with Melatonin... – PubMed
   Used [2x] | Anchor texts: "recent research analyzing 37 clinical trials", "[1]"
   Source match: ✅ Correct — systematic review of melatonin adverse events
   Anchor text: ✅ Accurate

⚠️ https://www.health.harvard.edu/[slug]
   Title: [not found in search results]
   Used [1x] | Anchor text: "Harvard Health reports"
   Status: Not indexed — may be live but could not be confirmed via search
   Action required: Manual click-check before publishing

❌ https://www.example-broken.com/page
   Title: [no results]
   Used [1x] | Anchor text: "recent clinical data"
   Status: No results found; domain appears unreachable
   Action required: Replace with a working source before publishing

INTERNAL LINKS
[List all [YOUR_DOMAIN]/blogs/ links with ✅ / ⚠️ / ❌]
[Confirm product page link present: ✅ / ❌]
[Confirm minimum 2 article links present: ✅ / ❌]

───────────────────────────────────────────────────────
ACTION ITEMS
───────────────────────────────────────────────────────
[Numbered list of every item requiring action, with suggested fix where possible]

═══════════════════════════════════════════════════════
VERDICT: [READY TO PUBLISH / NEEDS FIXES BEFORE PUBLISHING]
═══════════════════════════════════════════════════════
```

The VERDICT must be **READY TO PUBLISH** only if:
- All Phase 1 checks are ✅ or ⚠️ PARTIAL (TOC missing only Conclusion/FAQ)
- All Phase 2 URLs are ✅ LIVE, or all ⚠️ items have been manually verified
- No ❌ items remain unresolved in either phase

---

## Repairing Findings (In-Session)

Because you are still in the same session as article generation, repairs are fast. In many cases Claude will offer to fix problems immediately — the prompts below are fallbacks for situations where it does not.

**Duplicate H1:**
> `Remove the <h1> tag from the article body. The content beneath it should remain — only remove the tag itself.`

**Citation number mismatch:**
> `Citation [N] in the body refers to [source A] but the References list shows [N] as [source B]. Reconcile these throughout the article — decide which is correct and update every instance.`

**Dual-link pair mismatch:**
> `The dual-link pair in this sentence has two different sources: [anchor URL] and [footnote URL]. Decide which is the intended citation and make both links point to the same source. Update the References list if needed.`

**Ghost citation:**
> `The anchor link in this sentence points to [URL] but this source does not appear in the Research References list. Either add it to the References list with the correct number, or replace the link with the source that is already in the list.`

**Unsupported numerical claim:**
> `The claim "[sentence with figure]" contains a specific number with no citation. Either add a supporting citation or rephrase to remove the unsupported specificity.`

**Broken external link:**
> `The link to [URL] is broken. Find a replacement source that supports the same claim and update the article.`

**After all repairs:** Ask Claude to re-run the QA checker:
> `Re-run the article QA checker on the updated article.`

Do not publish until the re-check returns READY TO PUBLISH.

---

## Important Notes

### [YOUR_CMS_PLATFORM] H1 behaviour
[YOUR_CMS_PLATFORM] generates an H1 automatically from the article title field. The article HTML body must never contain an `<h1>` tag. This is invisible in markdown previews — it only manifests as a problem on the live rendered page. Check 1.1 catches this in the source HTML before publishing.

### PubMed / NCBI links
If the full URL search returns no result, search the PMID directly (e.g. `pubmed 31722088`). PubMed pages are reliably indexed and should always surface.

### Harvard Health / Sleep Foundation
These occasionally sit behind soft paywalls or have URL structures that change. If not found via URL search, search the article title to find the current URL, and update the article if it has moved.

### Internal [YOUR_BRAND_NAME] links
Blog post links may be too new to be indexed. Cross-reference against the hub index in Project Knowledge rather than relying on search results alone.

### Search-based verification has one known limitation
Web search confirms a page is indexed. A live but recently published or intentionally de-indexed page may show as ⚠️. Always recommend a manual click-check for ⚠️ items rather than treating them as broken.

### [YOUR_BRAND_NAME] product and homepage links
Stable and unlikely to break, but still verify via search and flag if they resolve to a redirect or to content that does not match the claimed context.

---

## Edge Cases

- **Duplicate anchor texts pointing to different URLs:** Flag as a potential reader confusion risk.
- **Same URL cited with contradictory anchor texts:** Flag for review (e.g. one instance says "study found X" and another says "study found Y" for the same URL).
- **[YOUR_BRAND_NAME] product page linked with non-product anchor text:** Flag — product page links should contextually make sense as product references.
- **Any URL containing `localhost`, `127.0.0.1`, or staging domains:** Flag as ❌ immediately without searching.
- **Google SERP URLs** (containing `google.com/search?`): Flag as ❌ immediately. Google search result pages are not citable sources and must be removed.

---

## Output Location

If the article file was provided as a path, offer to save the QA report as a `.txt` file alongside the article HTML for record-keeping.

---

*This skill supersedes `article-link-checker-SKILL.md`. Remove that file from Project Knowledge once this file is uploaded.*
*Last updated: April 2026*
