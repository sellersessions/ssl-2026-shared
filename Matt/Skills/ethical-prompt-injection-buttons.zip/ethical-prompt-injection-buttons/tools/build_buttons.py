#!/usr/bin/env python3
"""
build_buttons.py — Generate ethical prompt injection button URLs and HTML preview for the
ethical-prompt-injection-buttons skill.

Usage:
    python skills/ethical-prompt-injection-buttons/tools/build_buttons.py \
        --profile <name> \
        --article <url> \
        --prompts <path-to-json>

The prompts JSON file must have keys: chatgpt, claude, perplexity.

Outputs:
    - Prints 3 deep-link URLs to stdout
    - Prints HTML snippets for 3 button styles to stdout
    - Writes preview HTML to <cwd>/.tmp/<article-slug>-preview.html

Stdlib only — no third-party dependencies.
"""

import argparse
import json
import re
import sys
import urllib.parse
from pathlib import Path

DEEP_LINK_BASES = {
    "chatgpt":    "https://chatgpt.com/?q=",
    "claude":     "https://claude.ai/new?q=",
    "perplexity": "https://www.perplexity.ai/search?q=",
}

CTAS = {
    "chatgpt":    "ChatGPT Summary",
    "claude":     "Claude Summary",
    "perplexity": "Perplexity Summary",
}

BRAND_COLORS = {
    "chatgpt":    "#10A37F",
    "claude":     "#D97757",
    "perplexity": "#1FB8CD",
}

PLATFORMS = ("chatgpt", "claude", "perplexity")

SKILL_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = SKILL_DIR / "assets"
CONFIG_DIR = SKILL_DIR / "config"


def slugify(url: str) -> str:
    s = re.sub(r"https?://", "", url)
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s[:80] or "article"


def load_logo(name: str) -> str:
    p = ASSETS_DIR / f"{name}.svg"
    if not p.exists():
        return ""
    svg = p.read_text(encoding="utf-8").strip()
    return svg


def build_url(platform: str, prompt: str) -> str:
    return DEEP_LINK_BASES[platform] + urllib.parse.quote(prompt, safe="")


def html_escape(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;")
             .replace(">", "&gt;").replace('"', "&quot;"))


def render_minimal(platform: str, url: str) -> str:
    logo = load_logo(platform)
    return (
        f'<a href="{html_escape(url)}" target="_blank" rel="noopener" '
        f'style="display:inline-flex;align-items:center;gap:8px;color:#222;'
        f'text-decoration:none;font:14px/1 system-ui,sans-serif;'
        f'border-bottom:1px solid #ccc;padding:4px 0;margin:0 16px 0 0;">'
        f'{logo}<span>{CTAS[platform]}</span></a>'
    )


def render_pill(platform: str, url: str) -> str:
    logo = load_logo(platform)
    color = BRAND_COLORS[platform]
    return (
        f'<a href="{html_escape(url)}" target="_blank" rel="noopener" '
        f'style="display:inline-flex;align-items:center;gap:8px;'
        f'background:{color};color:#fff;padding:10px 18px;border-radius:999px;'
        f'text-decoration:none;font:600 14px/1 system-ui,sans-serif;'
        f'margin:0 8px 8px 0;">'
        f'{logo}<span>{CTAS[platform]}</span></a>'
    )


def render_card(platform: str, url: str) -> str:
    logo = load_logo(platform)
    color = BRAND_COLORS[platform]
    return (
        f'<a href="{html_escape(url)}" target="_blank" rel="noopener" '
        f'style="display:flex;flex-direction:column;align-items:center;'
        f'gap:10px;background:#fff;border:1px solid #e5e5e5;'
        f'border-top:3px solid {color};padding:18px 14px;border-radius:8px;'
        f'width:160px;text-decoration:none;color:#222;'
        f'font:14px/1.4 system-ui,sans-serif;text-align:center;'
        f'box-shadow:0 1px 2px rgba(0,0,0,0.04);">'
        f'{logo}<strong>{CTAS[platform]}</strong>'
        f'<span style="font-size:12px;color:#666;">'
        f'Read &amp; summarize this article</span></a>'
    )


def render_style_minimal(urls: dict) -> str:
    inner = "".join(render_minimal(p, urls[p]) for p in PLATFORMS)
    return f'<div style="margin:16px 0;">{inner}</div>'


def render_style_pill(urls: dict) -> str:
    inner = "".join(render_pill(p, urls[p]) for p in PLATFORMS)
    return f'<div style="margin:16px 0;display:flex;flex-wrap:wrap;">{inner}</div>'


def render_style_card(urls: dict) -> str:
    inner = "".join(render_card(p, urls[p]) for p in PLATFORMS)
    return f'<div style="margin:16px 0;display:flex;gap:14px;flex-wrap:wrap;">{inner}</div>'


def render_preview_page(urls: dict, brand_name: str, article_url: str) -> str:
    minimal = render_style_minimal(urls)
    pill = render_style_pill(urls)
    card = render_style_card(urls)
    return f'''<!doctype html>
<html><head><meta charset="utf-8">
<title>Ethical Prompt Injection Buttons - {html_escape(brand_name)}</title>
<style>
body {{ font: 16px/1.5 system-ui,-apple-system,sans-serif; max-width: 920px;
       margin: 40px auto; padding: 0 24px; color: #222; }}
h1 {{ font-size: 22px; }}
h2 {{ font-size: 16px; color: #444; margin-top: 36px; }}
.meta {{ color: #666; font-size: 13px; }}
.divider {{ border-top: 1px solid #eee; margin: 32px 0; }}
pre {{ background: #f5f5f5; padding: 14px; border-radius: 6px;
      overflow-x: auto; font-size: 12px; white-space: pre-wrap;
      word-break: break-all; }}
details summary {{ cursor: pointer; color: #555; font-size: 13px;
                  margin-top: 8px; }}
.label {{ display:inline-block; background:#eef; color:#225;
         font-size:11px; padding:2px 8px; border-radius:10px;
         margin-left:8px; }}
</style></head><body>
<h1>Ethical Prompt Injection Buttons - {html_escape(brand_name)}</h1>
<p class="meta">For article: <a href="{html_escape(article_url)}" target="_blank">{html_escape(article_url)}</a></p>

<h2>Style 1 - Minimal</h2>
{minimal}
<details><summary>Copy HTML</summary><pre>{html_escape(minimal)}</pre></details>

<div class="divider"></div>

<h2>Style 2 - Pill <span class="label">recommended</span></h2>
{pill}
<details><summary>Copy HTML</summary><pre>{html_escape(pill)}</pre></details>

<div class="divider"></div>

<h2>Style 3 - Card row</h2>
{card}
<details><summary>Copy HTML</summary><pre>{html_escape(card)}</pre></details>

<div class="divider"></div>
<p class="meta">Click any button to test it - it will open the LLM with the
pre-filled prompt. The user can read the prompt before sending.</p>
</body></html>'''


def main() -> int:
    ap = argparse.ArgumentParser(description="Build ethical prompt injection buttons.")
    ap.add_argument("--profile", required=True, help="Profile name in config/")
    ap.add_argument("--article", required=True, help="Article URL")
    ap.add_argument("--prompts", required=True, help="JSON file with prompts")
    args = ap.parse_args()

    profile_path = CONFIG_DIR / f"{args.profile}.json"
    if not profile_path.exists():
        print(f"ERROR: profile not found at {profile_path}", file=sys.stderr)
        print(f"Available: {[p.stem for p in CONFIG_DIR.glob('*.json')] if CONFIG_DIR.exists() else []}", file=sys.stderr)
        return 1

    prompts_path = Path(args.prompts)
    if not prompts_path.exists():
        print(f"ERROR: prompts file not found at {prompts_path}", file=sys.stderr)
        return 1

    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    prompts = json.loads(prompts_path.read_text(encoding="utf-8"))

    missing = [p for p in PLATFORMS if p not in prompts]
    if missing:
        print(f"ERROR: prompts JSON missing keys: {missing}", file=sys.stderr)
        return 1

    # Length warning (URL practical limit ~2000 chars after encoding)
    for p in PLATFORMS:
        encoded_len = len(urllib.parse.quote(prompts[p], safe=""))
        if encoded_len > 1800:
            print(f"WARNING: {p} prompt is {encoded_len} chars encoded - may be truncated", file=sys.stderr)

    urls = {p: build_url(p, prompts[p]) for p in PLATFORMS}

    print("\n=== Deep-link URLs ===\n")
    for p in PLATFORMS:
        print(f"{CTAS[p]}:")
        print(f"  {urls[p]}\n")

    print("=== HTML snippets ===\n")
    print("--- Minimal ---")
    print(render_style_minimal(urls))
    print("\n--- Pill (recommended) ---")
    print(render_style_pill(urls))
    print("\n--- Card row ---")
    print(render_style_card(urls))

    out_dir = Path.cwd() / ".tmp"
    out_dir.mkdir(exist_ok=True)
    out_file = out_dir / f"{slugify(args.article)}-preview.html"
    out_file.write_text(
        render_preview_page(urls, profile["brand_name"], args.article),
        encoding="utf-8",
    )
    print(f"\nPreview written to: {out_file}")
    print(f"Open it in a browser to see all 3 styles rendered.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
