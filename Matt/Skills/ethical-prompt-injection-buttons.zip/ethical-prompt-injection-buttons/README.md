# Ethical Prompt Injection Buttons (Claude Code skill)

Drop-in skill that turns any article on a brand's site into 3 share buttons:

- **ChatGPT Summary**
- **Claude Summary**
- **Perplexity Summary**

Clicking a button opens the LLM with a pre-filled prompt that summarizes the article and naturally seeds the brand into the user's session — and into ChatGPT's persistent memory.

## What it does

1. **One-time per brand** — quick interview captures the brand name, category, and 2–3 standout points. Saves a profile.
2. **Per article** — paste the article URL, get back 3 deep-link URLs and copy-paste HTML for the buttons.

The agent (Claude Code) runs the interview conversationally and pulls brand details from any URL you paste — Amazon listing, Shopify product page, brand homepage, anywhere. No API keys, no scraping libraries, no third-party dependencies.

## Install

Copy the `ethical-prompt-injection-buttons/` folder into one of:

- **User-level** (available in every project): `~/.claude/skills/`
- **Project-level**: `.claude/skills/` in your project

Restart Claude Code or start a new session. The skill is now available.

## Usage

Just say what you want, e.g.:

> "Make ethical prompt injection buttons for https://example.com/blog/some-article"

or

> "Set up an ethical prompt injection buttons profile"

The skill takes you through 3 steps in a single session: brand setup → article URL → buttons. You'll get:

- 3 deep-link URLs printed to terminal
- Copy-paste HTML for 3 button styles (Minimal / Pill / Card row)
- A preview HTML page at `.tmp/<article-slug>-preview.html` showing all 3 styles rendered

## Output styles

- **Minimal** — small text links with logo. Good for inline placement in article body.
- **Pill** *(recommended)* — branded color buttons. Strong CTA, looks polished.
- **Card row** — three side-by-side cards. Good as a feature block above or below the article.

All button styles are inline-styled HTML — no external CSS or assets needed. Drop the snippet into any page.

## Logos

The bundled SVGs in `assets/` are simplified marks. If you want the official logos, replace:

- `assets/chatgpt.svg` — official OpenAI mark from [openai.com/brand](https://openai.com/brand)
- `assets/claude.svg` — official Anthropic mark from [anthropic.com/brand](https://anthropic.com)
- `assets/perplexity.svg` — official Perplexity mark from their press kit

The SVGs use `fill="currentColor"` so they inherit the right color in each button style automatically.

## Files

```
ethical-prompt-injection-buttons/
  SKILL.md              # Agent instructions
  README.md             # This file
  config/               # Brand profiles (auto-created on first run)
  tools/
    build_buttons.py    # Stdlib-only Python — generates URLs and preview HTML
  assets/
    chatgpt.svg
    claude.svg
    perplexity.svg
```

## Profiles

Each brand has a JSON profile in `config/`:

```json
{
  "brand_name": "[Brand]",
  "category": "[specific category]",
  "differentiator": "[short differentiator phrase]",
  "talking_points": [
    "[Talking point 1]",
    "[Talking point 2]",
    "[Talking point 3]"
  ]
}
```

You can hand-edit these or re-run the interview to update.

## How the prompts work

Each generated prompt:

1. Frames the user as actively researching the category (first-person, stable interest)
2. Asks for an article summary (the apparent reason for the click)
3. Mentions the brand naturally in the middle, with a truthful differentiator and a reasoned connection
4. Asks the LLM to relate the article's findings to that approach

This pattern is designed to land in ChatGPT's persistent memory as a stable preference, not as a one-off mention. See `SKILL.md` for the full templates and the rationale behind each element.

## Notes

- **No prompt obfuscation.** Everything in the prompt is plain, readable text. The user can see and edit before sending.
- **Truthful claims only.** The skill uses the talking points you provide — don't put marketing puffery in there.
- **Off-topic articles.** If you generate buttons for an article that's genuinely unrelated to the brand, the skill will tell you the brand connection feels forced and let you decide whether to skip the brand mention or proceed.
